import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import MainMenu from "./features/main-menu/MainMenu";
import AssetRegistry from "./features/asset-registry/AssetRegistry";
import MaintenanceReport from "./features/maintenance-report/MaintenanceReport";
import Dashboard, { type DashboardNav } from "./features/dashboard/Dashboard";
import Administration, {
  type AdminSection,
  type GroupId,
} from "./features/administration/Administration";
import MaintenanceTriggers from "./features/asset-registry/MaintenanceTriggers";
import TemplateBuilder from "./features/mri-template-builder/TemplateBuilder";
import SelectAssetForReport from "./features/mri-reporting/SelectAssetForReport";
import ReportWizard from "./features/mri-reporting/ReportWizard";
import UiLab from "./features/ui-lab/UiLab";
import DistanceMapTest from "./features/distance-map-test/DistanceMapTest";
import PendingApprovals from "./features/mri-reporting/PendingApprovals";
import RectificationQueue from "./features/mri-reporting/RectificationQueue";
import ReportReviewQueue from "./features/mri-reporting/ReportReviewQueue";
import MyReportsQueue from "./features/mri-reporting/MyReportsQueue";
import ReportFlow from "./features/mri-reporting/ReportFlow";
import AssetFlow from "./features/mri-reporting/AssetFlow";
import type { Theme } from "./lib/theme";
import { CurrentUserProvider } from "./lib/currentUser";
import WindowTitle from "./lib/WindowTitle";
import UserPickerGate from "./lib/UserPickerGate";
import UserBadge from "./lib/UserBadge";

type Screen =
  | "menu"
  | "assets"
  | "reports"
  | "dashboard"
  | "admin"
  | "triggers"
  | "uilab"
  | "distance-map-test"
  | "template-builder"
  | "select-asset-report"
  | "report-wizard"
  | "pending-approvals"
  | "rectification-queue"
  | "report-review-queue"
  | "my-reports-queue"
  | "report-flow"
  | "asset-flow";
type MrLevel = "MR-I" | "MR-II" | "MR-III";

const queryClient = new QueryClient();

function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [mrLevel, setMrLevel] = useState<MrLevel | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<{
    id: number;
    code: string;
  } | null>(null);

  const [selectedTemplate, setSelectedTemplate] = useState<{
    id: number;
    name: string;
  } | null>(null);
  const [adminActive, setAdminActive] = useState<AdminSection>("users");
  const [adminOpenGroup, setAdminOpenGroup] = useState<GroupId>("users");

  function handleOpenTemplate(id: number, name: string) {
    setSelectedTemplate({ id, name });
    setScreen("template-builder");
  }

  const [selectedReportId, setSelectedReportId] = useState<number | null>(null);
  const [viewOnlyReport, setViewOnlyReport] = useState(false);
  // Where the report wizard was opened FROM (Select Asset for Report, Asset MR-I
  // History, Report Review Queue, My Reports Queue, ...) -- captured at open time so
  // Back returns to that same screen instead of always landing on Select Asset for
  // Report ("reports"), which is what it did before regardless of the true origin.
  const [reportWizardOrigin, setReportWizardOrigin] = useState<Screen>("reports");

  // Attention Required screens (and reports / flows opened from them) show the signed-in
  // user's name and tier top-right.
  const ATTENTION_SCREENS: Screen[] = ["pending-approvals", "rectification-queue", "report-review-queue", "my-reports-queue"];

  function handleReportCreated(reportId: number, viewOnly: boolean = false) {
    setReportWizardOrigin(screen);
    setSelectedReportId(reportId);
    setViewOnlyReport(viewOnly);
    setScreen("report-wizard");
  }

  // Document flow (read-only maps of one report, or of one asset over time). Opening a flow
  // from another flow pushes onto a small stack, so Back steps through the flows you visited
  // and finally returns to the screen the first flow was opened from.
  type FlowEntry = { type: "report" | "asset"; id: number };
  const [flowStack, setFlowStack] = useState<FlowEntry[]>([]);
  const [flowOrigin, setFlowOrigin] = useState<Screen>("my-reports-queue");
  // Dashboard view and chosen asset live here so Back from a flow returns to the same panel.
  const [dashboardNav, setDashboardNav] = useState<DashboardNav>({ view: "hub", asset: null });
  const currentFlow = flowStack.length > 0 ? flowStack[flowStack.length - 1] : null;

  function openFlow(entry: FlowEntry) {
    if (screen !== "report-flow" && screen !== "asset-flow") {
      setFlowOrigin(screen);
      setFlowStack([entry]);
    } else {
      setFlowStack((s) => [...s, entry]);
    }
    setScreen(entry.type === "report" ? "report-flow" : "asset-flow");
  }

  function handleOpenFlow(reportId: number) {
    openFlow({ type: "report", id: reportId });
  }

  function handleOpenAssetFlow(assetId: number) {
    openFlow({ type: "asset", id: assetId });
  }

  function handleFlowBack() {
    if (flowStack.length > 1) {
      const rest = flowStack.slice(0, -1);
      setFlowStack(rest);
      setScreen(rest[rest.length - 1].type === "report" ? "report-flow" : "asset-flow");
    } else {
      setFlowStack([]);
      setScreen(flowOrigin);
    }
  }

  const [theme, setTheme] = useState<Theme>("light");

  function handleThemeChange(t: Theme) {
    setTheme(t);
  }

  function handleNavigate(target: Screen, level?: MrLevel) {
    if (level) setMrLevel(level);
    // Opening the Dashboard from the main menu still starts at its hub, as before.
    if (target === "dashboard") setDashboardNav({ view: "hub", asset: null });
    setScreen(target);
  }

  function handleViewTriggers(assetId: number, assetCode: string) {
    setSelectedAsset({ id: assetId, code: assetCode });
    setScreen("triggers");
  }

  const showUserBadge =
    ATTENTION_SCREENS.includes(screen) ||
    (screen === "report-wizard" && ATTENTION_SCREENS.includes(reportWizardOrigin)) ||
    ((screen === "report-flow" || screen === "asset-flow") && ATTENTION_SCREENS.includes(flowOrigin));

  return (
    <QueryClientProvider client={queryClient}>
      <CurrentUserProvider>
        <WindowTitle />
        <div className="app" data-theme={theme}>
          <style>{`
          .app {
            --neu-inset: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            --neu-raised: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
            --neu-inset-deep: inset 3px 3px 8px var(--neu-shadow-dark), inset -3px -3px 8px var(--neu-shadow-light);
            --neu-inset-sm: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
            --neu-inset-well: inset 2px 2px 5px var(--neu-shadow-dark), inset -2px -2px 5px var(--neu-shadow-light);
            --neu-raised-sm: 3px 3px 6px var(--neu-shadow-dark), -3px -3px 6px var(--neu-shadow-light);
            --tab-track: rgba(0,0,0,0.04);
            --st-amber: #d97706;
            --st-blue: #2f6fed;
            --st-red: #c0392b;
            --st-teal: #0d9488;
            --st-grey: #6b7280;
            --on-status: #fff;
            --disabled-bg: #e9ebed;
            --chip-bg: var(--neu-shadow-dark);
            --st-green: #16a34a;
            --hero-veil: linear-gradient(100deg, rgba(255,255,255,0.94) 0%, rgba(255,255,255,0.82) 30%, rgba(255,255,255,0.45) 65%, rgba(255,255,255,0.15) 100%);
            --glass-bg: rgba(255,255,255,0.5);
            --glass-bg-strong: rgba(255,255,255,0.7);
            --glass-shadow: 0 1px 4px rgba(0,0,0,0.08);
            --glass-shadow-strong: 0 1px 4px rgba(0,0,0,0.12);
            --text-halo: 0 1px 4px rgba(255,255,255,0.85);
            --shadow-card: 0 2px 8px rgba(0,0,0,0.05);
            --shadow-card-lg: 0 2px 10px rgba(0,0,0,0.06);
            --shadow-pop: 0 2px 8px rgba(0,0,0,0.12);
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
          }
          .icon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(56px, 1fr)); gap: 8px; max-height: 320px; overflow-y: auto; margin-bottom: 14px; }
          .icon-cell { width: 56px; height: 56px; padding: 0; display: flex; align-items: center; justify-content: center; }
          .icon-cell img { filter: var(--icon-filter, none); }
          .panel.panel-flat { box-shadow: none; border: 1px solid var(--border); padding: 18px; }
          .inset-well { width: 72px; height: 72px; border-radius: 14px; background: var(--neu-bg); box-shadow: var(--neu-inset); display: flex; align-items: center; justify-content: center; }
          :root, [data-theme="light"] {
            --bg: #f3f4f5;
            --neu-bg: #e7eaf0;
            --neu-shadow-dark: #b9bfca;
            --neu-shadow-light: #ffffff;
            --surface: #ffffff;
            --border: #e0e2e5;
            --text: #1a1d1f;
            --text-soft: #6b7280;
            --accent: #0f6e56;
            --accent-soft: #e1f5ee;
            --accent-blue: #2f6fed;
            --accent-blue-deep: #1a4d8f;
            --chart-violet: #7c61cc;
            --chart-green: #3d9463;
            --hover-highlight: #e9f1fe;            
            --warn: #a3591b;
            --warn-soft: #faeeda;
            --danger: #a32d2d;
            --danger-soft: #fcebeb;
            --success: #1f7a4d;
            --success-soft: #dcf3e4;
            --radius: 10px;
            --mono: ui-monospace, "JetBrains Mono", Consolas, monospace;
            --sans: -apple-system, "Segoe UI", Inter, sans-serif;
          }

          [data-theme="dark"] {
            --bg: #202226;
            --neu-bg: #2a2d33;
            --neu-shadow-dark: #1c1e22;
            --neu-shadow-light: #383c44;
            --surface: #2a2d33;
            --border: #3a3d44;
            --text: #e8e9eb;
            --text-soft: #9aa0a8;
            --accent: #3ddc9c;
            --accent-soft: #17352a;
            --accent-blue: #5b9bff;
            --accent-blue-deep: #3a6dc4;
            --chart-violet: #a48ce8;
            --chart-green: #5cb383;
            --hover-highlight: #263449;            
            --warn: #e0a94f;
            --warn-soft: #3a2f1a;
            --danger: #f0716b;
            --danger-soft: #3a1f1e;
            --success: #4ade80;
            --success-soft: #1c3a2a;
          }

          [data-theme="ocean"] {
            --bg: #eaf2f7;
            --neu-bg: #dde9f0;
            --neu-shadow-dark: #b7cad6;
            --neu-shadow-light: #ffffff;
            --surface: #ffffff;
            --border: #cddbe4;
            --text: #16303e;
            --text-soft: #5b7688;
            --accent: #0f8f8a;
            --accent-soft: #dcf3f1;
            --accent-blue: #1c7fd6;
            --accent-blue-deep: #144e82;
            --chart-violet: #6a5bc2;
            --chart-green: #2f9e6e;
            --hover-highlight: #d3e7f5;            
            --warn: #b5762a;
            --warn-soft: #fbeddb;
            --danger: #b5433d;
            --danger-soft: #fbe5e3;
            --success: #16805a;
            --success-soft: #d3f0e3;
          }

          [data-theme="sepia"] {
            --bg: #f1e9d8;
            --neu-bg: #e8ddc9;
            --neu-shadow-dark: #c9bb9d;
            --neu-shadow-light: #ffffff;
            --surface: #fbf6ec;
            --border: #ddccac;
            --text: #3c2f1e;
            --text-soft: #7a6a51;
            --accent: #6b7a2e;
            --accent-soft: #e8edd3;
            --accent-blue: #a05c2c;
            --accent-blue-deep: #7a4520;
            --chart-violet: #7a5a9e;
            --chart-green: #6b7a2e;
            --hover-highlight: #ede0c8;            
            --warn: #a3591b;
            --warn-soft: #f2e2c6;
            --danger: #9c3d33;
            --danger-soft: #f2ddd8;
            --success: #56702c;
            --success-soft: #e3edd0;
          }

          [data-theme="sprint"] {
            --bg: #05a1c7;
            --neu-bg: #1cabce;
            --neu-shadow-dark: #0489a8;
            --neu-shadow-light: #3fc0dd;
            --surface: #ffffff;
            --border: #0d8fae;
            --text: #ffffff;
            --text-soft: #d7f2fa;
            --accent: #b90005;
            --accent-soft: #ffe0e1;
            --accent-blue: #b90005;
            --accent-blue-deep: #8a0004;
            --chart-violet: #7c61cc;
            --chart-green: #3d9463;
            --warn: #e0a94f;
            --warn-soft: #3a2f1a;
             --danger: #b90005;
            --danger-soft: #ffe0e1;
            --success: #0f7a4a;
            --success-soft: #d9f5e6;
            --hover-highlight: #2bb8d8;
          }

          * { box-sizing: border-box; }
          html { font-size: 17px; }
          html, body, #root { height: 100%; margin: 0; }
          /* The app scrolls inside .content; the window itself never scrolls (avoids a stray
             scrollbar when the zoom-corrected width rounds a pixel over). */
          html, body { overflow: hidden; }          
          .app { font-family: var(--sans); background: var(--bg); color: var(--text); height: calc(100vh / 1.05); width: calc(100vw / 1.05); display: flex; flex-direction: column; overflow: hidden; zoom: 1.05; }
          .ui-nav {
            padding: 16px 16px 0;
            display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;
          }
          .user-badge { font-size: 13px; color: var(--text); white-space: nowrap; }

          .content {
            flex: 1; min-width: 0; overflow-y: auto; padding: clamp(12px, 1.6vw, 18px); background: var(--neu-bg);
            container-type: inline-size;
          }

          @keyframes screen-fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .screen-fade {
            animation: screen-fade-in 0.32s cubic-bezier(0.22, 1, 0.36, 1);
            min-height: 100%;
          }
          .screen-fade.fixed-height {
            height: 100%;
            display: flex;
            flex-direction: column;
            overflow: hidden;
          }

          .menu-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: clamp(14px, 3cqi, 28px);
            width: 100%;
            padding-bottom: clamp(90px, 14vh, 120px);
          }
            
          @container (max-width: 680px) {
            .menu-grid { grid-template-columns: repeat(2, 1fr); }
          }
          @container (max-width: 380px) {
            .menu-grid { grid-template-columns: 1fr; }
          }
          @container (max-width: 560px) {
            .menu-layout { flex-direction: column; }
            .kpi-sidebar { width: 100%; flex-direction: row; }
            .kpi-mini-card { flex: 1; }
          }
          .menu-card {
            background: var(--neu-bg);
            border-radius: 22px;
            padding: clamp(16px, 3.4cqi, 26px) clamp(14px, 3cqi, 22px);
            text-align: center;
            cursor: pointer;
            border: none;
            box-shadow: 9px 9px 18px var(--neu-shadow-dark), -9px -9px 18px var(--neu-shadow-light);
            transition: box-shadow 0.18s, transform 0.18s;
            display: flex;
            flex-direction: column;
            justify-content: center;
            min-height: clamp(130px, 20vh, 210px);
          }
          .menu-card:hover {
            transform: translateY(-3px);
            box-shadow: 12px 12px 22px var(--neu-shadow-dark), -12px -12px 22px var(--neu-shadow-light);
          }
          .menu-card:active {
            transform: translateY(0);
            box-shadow: inset 6px 6px 12px var(--neu-shadow-dark), inset -6px -6px 12px var(--neu-shadow-light);
          }
          .menu-icon-wrap {
            width: clamp(40px, 10cqi, 52px);
            height: clamp(40px, 10cqi, 52px);
            margin: 0 auto clamp(8px, 2cqi, 12px);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #07080a;
            background: var(--neu-bg);
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light);
            transition: color 0.18s;
          }

          .menu-card:hover .menu-icon-wrap { color: #1a4d8f; }
          .menu-card:active .menu-icon-wrap { color: #0d2f5c; }
          .menu-icon-wrap svg { width: clamp(20px, 5cqi, 26px); height: clamp(20px, 5cqi, 26px); }

          .menu-card h3 { font-size: clamp(15px, 3.4cqi, 18px); margin: 0 0 6px; font-weight: 600; }
          .menu-card p { font-size: clamp(13px, 2.8cqi, 14.5px); color: var(--text-soft); margin: 0; line-height: 1.4; }

          .mr-level-row {
            display: flex;
            gap: 8px;
            justify-content: center;
            margin-top: 14px;
            height: 38px;
            animation: mr-level-in 0.18s ease-out;
          }
          @keyframes mr-level-in {
            from { opacity: 0; transform: translateY(-4px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .mr-level-btn {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            padding: 0;
            font-size: 13px;
            font-weight: 700;
            color: var(--accent-blue);
            background: var(--neu-bg);
            box-shadow: 3px 3px 6px var(--neu-shadow-dark), -3px -3px 6px var(--neu-shadow-light);
          }
          .mr-level-btn:hover {
            box-shadow: 4px 4px 8px var(--neu-shadow-dark), -4px -4px 8px var(--neu-shadow-light);
          }
          .mr-level-btn:active {
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }
          .uilab-fab {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            border: none;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text-soft);
            background: var(--neu-bg);
            box-shadow: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
            transition: box-shadow 0.15s, color 0.15s, transform 0.15s;
            z-index: 10;
          }
          .uilab-fab:hover { color: #2f6fed; transform: translateY(-2px); }
          .uilab-fab:active {
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            transform: translateY(0);
          }
          .uilab-fab svg { width: 19px; height: 19px; }  

          .menu-screen {
            display: flex;
            flex-direction: column;
            flex: 1;
            min-height: 0;
            max-height: 100%;
            overflow: hidden;
            position: relative;
            padding: 16px 10px 0;
          }


          .current-user-banner {
            position: absolute;
            top: -2px;
            right: 0;
            font-size: 11px;
            color: var(--text-soft);
            font-family: var(--mono);
            opacity: 0.75;
            pointer-events: none;
          }

          .kpi-footer {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            flex-direction: row;
            gap: 12px;
            padding: 12px 0 0;
            background: var(--neu-bg);
            z-index: 5;
          }

          .kpi-footer-item {
            display: flex;
            flex-direction: column;
            gap: 6px;
            padding: 12px 16px;
            border-radius: 14px;
            cursor: pointer;
            min-width: 150px;
            background: var(--neu-bg);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
            transition: box-shadow 0.15s, transform 0.15s;
          }
          .kpi-footer-item:hover {
            transform: translateY(-1px);
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light);
          }
          .kpi-footer-item:active {
            transform: translateY(0);
            box-shadow: inset 6px 6px 12px var(--neu-shadow-dark), inset -6px -6px 12px var(--neu-shadow-light);
          }
          .kpi-footer-label {
            font-size: 11px;
            color: var(--text-soft);
            white-space: nowrap;
          }
          .kpi-footer-row {
            display: flex;
            align-items: baseline;
            gap: 8px;
          }
          .kpi-footer-value {
            font-family: var(--mono);
            font-size: 17px;
            font-weight: 700;
            color: var(--text);
          }
          .kpi-footer-value.pale-red {
            color: #c98a8a;
          }
          .kpi-footer-unit {
            font-size: 11px;
            font-weight: 500;
            color: var(--text-soft);
            margin-left: 1px;
          }
          .kpi-footer-delta {
            font-family: var(--mono);
            font-size: 11px;
            font-weight: 600;
          }
          .kpi-footer-delta.good { color: var(--accent); }
          .kpi-footer-delta.bad { color: var(--danger); }

          .kpi-gauge-track {
            position: relative;
            height: 6px;
            border-radius: 4px;
            overflow: hidden;
            background: linear-gradient(90deg, #d9534f 0%, #e0a94f 45%, #6fbf73 75%, #3d9463 100%);
          }
          .kpi-gauge-mask {
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            background: var(--neu-bg);
            box-shadow: inset 2px 0 3px var(--neu-shadow-dark);
          }

          @media (max-width: 480px) {
            .kpi-footer { gap: 8px; }
            .kpi-footer-item { min-width: 130px; padding: 10px 12px; }
          }

          .theme-fab {
            position: fixed;
            bottom: 20px;
            right: 74px;
            width: 44px;
            height: 44px;
            border-radius: 50%;
            border: none;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text-soft);
            background: var(--neu-bg);
            box-shadow: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
            transition: box-shadow 0.15s, color 0.15s, transform 0.15s;
            z-index: 10;
          }
          .theme-fab:hover { color: var(--accent-blue); transform: translateY(-2px); }
          .theme-fab:active {
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            transform: translateY(0);
          }
          .theme-fab svg { width: 19px; height: 19px; }

          .theme-picker-overlay {
            position: fixed;
            inset: 0;
            z-index: 60;
          }

          .theme-picker {
            position: fixed;
            bottom: 72px;
            right: 20px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            padding: 10px;
            border-radius: 16px;
            background: var(--neu-bg);
            box-shadow: 10px 10px 20px var(--neu-shadow-dark), -10px -10px 20px var(--neu-shadow-light);
            animation: orb-in 0.2s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
          }

          .theme-option {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border-radius: 10px;
            border: none;
            background: transparent;
            color: var(--text-soft);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            box-shadow: none;
            white-space: nowrap;
            transition: background 0.12s, color 0.12s;
          }
          .theme-option:hover { background: rgba(0,0,0,0.04); }
          .theme-option.active {
            color: var(--text);
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }

          .gate-theme-picker {
            position: absolute; top: 16px; right: 20px; z-index: 20;
            display: flex; gap: 4px; padding: 5px;
            border-radius: 14px;
            background: var(--glass-bg-strong); box-shadow: var(--glass-shadow-strong);
            backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
          }
          .theme-swatch {
            width: 18px;
            height: 18px;
            border-radius: 50%;
            flex-shrink: 0;
            box-shadow: inset 0 0 0 1px rgba(0,0,0,0.1);
          }

          .side-drawer-handle {
            position: fixed;
            top: 50%;
            right: 0;
            transform: translateY(-50%);
            width: 42px;
            height: 96px;
            border-radius: 18px 0 0 18px;
            border: none;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text-soft);
            background: color-mix(in srgb, var(--neu-bg) 60%, transparent);
            box-shadow: -5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
            transition: color 0.15s, width 0.15s;
            z-index: 20;
          }
          .side-drawer-handle:hover { color: var(--accent-blue); width: 51px; }
          .side-drawer-handle svg { width: 24px; height: 24px; }

          .side-drawer-handle-wide { width: 190px; }
          .side-drawer-handle-wide:hover { width: 190px; }

          .side-drawer-handle-avatar {
            width: 285px;
            height: auto;
            border-radius: 0;
            background: transparent;
            box-shadow: none;
            padding: 0;
            align-items: center;
            justify-content: flex-start;
          }
          .side-drawer-handle-avatar:hover { width: 285px; }
        .drawer-handle-avatar-circle {
          position: relative;
          z-index: 2;
          width: 71px;
          height: 71px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #ffffff;
          box-shadow: 4px 4px 10px var(--neu-shadow-dark), -2px -2px 6px var(--neu-shadow-light);
          flex-shrink: 0;
        }
        .drawer-handle-avatar-circle svg { width: 33px; height: 33px; }
          .drawer-handle-avatar-count {
            font-size: 22px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1;
          }
          @keyframes handle-alert-throb {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.08); }
          }
          @keyframes handle-alert-ring {
            0% { opacity: 0.95; transform: scale(0.8); }
            80% { opacity: 0; transform: scale(2.2); }
            100% { opacity: 0; transform: scale(2.2); }
          }
          .drawer-handle-avatar-circle-alert {
            animation: handle-alert-throb 1.3s ease-in-out infinite;
          }
          .drawer-handle-avatar-circle-alert::after {
            content: "";
            position: absolute;
            inset: -18px;
            border-radius: 50%;
            background: radial-gradient(circle, var(--danger) 0%, color-mix(in srgb, var(--danger) 70%, transparent) 55%, transparent 85%);
            animation: handle-alert-ring 1.3s ease-out infinite;
            pointer-events: none;
          }
          .drawer-handle-avatar-info {
            position: relative;
            z-index: 1;
            margin-left: -27px;
            padding: 15px 21px 15px 45px;
            border-radius: 0 14px 14px 0;
            background: var(--neu-bg);
            box-shadow: -5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
            display: flex;
            flex-direction: column;
            gap: 2px;
            width: 228px;
            flex: 0 0 auto;
          }
        .side-drawer-handle-name {
          font-size: 12px;
          font-weight: 600;
          color: var(--text);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 100%;
        }
        .side-drawer-handle-role {
          font-size: 10.5px;
          color: var(--text-soft);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 100%;
        }

          .side-drawer-overlay {
            position: fixed;
            inset: 0;
            z-index: 500;
            background: rgba(0,0,0,0.15);
          }

          .side-drawer {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            width: min(300px, 84vw);
            background: var(--neu-bg);
            font-family: var(--sans);
            color: var(--text);
            box-shadow: -10px 0 30px rgba(0,0,0,0.18);
            padding: 20px 16px;
            display: flex;
            flex-direction: column;
            gap: 18px;
            overflow-y: auto;
            animation: drawer-in 0.22s cubic-bezier(0.22, 1, 0.36, 1);
          }
          .side-drawer-wide {
            width: min(420px, 90vw);
          }
          @keyframes drawer-in {
            from { transform: translateX(100%); }
            to { transform: translateX(0); }
          }

          .drawer-user-card {
            padding: 14px;
            border-radius: 14px;
            background: var(--neu-bg);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
          }
          .drawer-user-name { font-size: 14px; font-weight: 600; color: var(--text); word-break: break-all; }
          .drawer-user-role { font-size: 12px; color: var(--text-soft); margin-top: 4px; }

          .drawer-section-label {
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.4px;
            text-transform: uppercase;
            color: var(--text-soft);
            margin-bottom: 4px;
          }

          .drawer-nav-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            width: 100%;
            padding: 10px 12px;
            border-radius: 10px;
            border: none;
            background: transparent;
            color: var(--text-soft);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            text-align: left;
            transition: background 0.12s, color 0.12s;
          }
          .drawer-nav-btn:hover { background: rgba(0,0,0,0.04); color: var(--text); }
          .drawer-nav-btn svg { width: 18px; height: 18px; flex-shrink: 0; }  


          .level-orb {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2px;
            cursor: pointer;
            background: var(--neu-bg);
            box-shadow: 10px 10px 20px var(--neu-shadow-dark), -10px -10px 20px var(--neu-shadow-light);
            opacity: 0;
            transform: scale(0.8);
            animation: orb-in 0.35s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
            transition: box-shadow 0.15s, transform 0.15s;
          }
          @keyframes orb-in {
            from { opacity: 0; transform: scale(0.8); }
            to { opacity: 1; transform: scale(1); }
          }
          .level-orb:hover {
            transform: scale(1.05);
            box-shadow: 13px 13px 24px var(--neu-shadow-dark), -13px -13px 24px var(--neu-shadow-light);
          }
          .level-orb:active {
            transform: scale(0.97);
            box-shadow: inset 6px 6px 12px var(--neu-shadow-dark), inset -6px -6px 12px var(--neu-shadow-light);
          }

          .level-orb-short {
            font-size: 26px;
            font-weight: 700;
            color: #2f6fed;
          }
          .level-orb-label {
            font-size: 13px;
            font-weight: 600;
            color: var(--text);
            margin-top: 2px;
          }
          .level-orb-desc {
            font-size: 10.5px;
            color: var(--text-soft);
            text-align: center;
            padding: 0 10px;
          }          

          .header { display: flex; align-items: baseline; justify-content: space-between; flex-wrap: wrap; gap: 8px; margin-bottom: 20px; }
          .header h1 { font-size: clamp(20px, 2.2vw, 25px); font-weight: 600; margin: 0; letter-spacing: -0.01em; }
          .header .sub { font-size: 14px; color: var(--text-soft); font-family: var(--mono); min-width: 0; }

          .layout { display: grid; grid-template-columns: minmax(280px, 340px) 1fr; gap: 20px; align-items: start; }
          @container (max-width: 720px) { .layout { grid-template-columns: 1fr; } }

          .panel {
            background: var(--neu-bg);
            border: none;
            border-radius: 20px;
            padding: 22px;
            box-shadow: 8px 8px 16px var(--neu-shadow-dark), -8px -8px 16px var(--neu-shadow-light);
          }
          .panel h2 { font-size: 15px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.04em; color: var(--text-soft); margin: 0 0 14px 0; }
          .field { margin-bottom: 12px; }
          .field label { display: block; font-size: 14px; color: var(--text-soft); margin-bottom: 4px; }
          .field input[type="text"], .field input[type="number"], .field select {
            width: 100%; padding: 12px 14px; border: none; border-radius: 10px;
            font-size: 15px; font-family: var(--sans); background: var(--neu-bg); color: var(--text);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
          }
          .field input:disabled, .field select:disabled {
            background: var(--neu-bg); color: var(--text-soft); box-shadow: none; cursor: not-allowed; opacity: 0.7;
          }
          .field input:focus, .field select:focus {
            outline: none;
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light), 0 0 0 2px #2f6fed33;
          }

          /* Global neumorphic text boxes: every text-like input, textarea and select */
          input:not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="button"]):not([type="submit"]):not([type="range"]):not([type="color"]),
          textarea, select {
            padding: 10px 14px; border: none; border-radius: 10px;
            font-size: 15px; font-family: var(--sans); background: var(--neu-bg); color: var(--text);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
            outline: none; box-sizing: border-box;
          }
          input:not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="button"]):not([type="submit"]):not([type="range"]):not([type="color"]):focus,
          textarea:focus, select:focus {
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light), 0 0 0 2px #2f6fed33;
          }
          input:disabled, textarea:disabled, select:disabled { color: var(--text-soft); box-shadow: none; cursor: not-allowed; opacity: 0.7; }

          .neu-select {
            padding: 12px 14px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-family: var(--sans);
            background: var(--neu-bg);
            color: var(--text);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
            width: 100%;
          }
          .neu-select:focus {
            outline: none;
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light), 0 0 0 2px #2f6fed33;
          }
          .neu-select:disabled {
            background: var(--neu-bg);
            color: var(--text-soft);
            box-shadow: none;
            cursor: not-allowed;
            opacity: 0.7;
          }
          .asset-select-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(460px, 1fr));
            gap: 20px;
          }
          .asset-select-card {
            background: var(--neu-bg);
            border-radius: 18px;
            padding: 22px;
            box-shadow: 6px 6px 12px var(--neu-shadow-dark), -6px -6px 12px var(--neu-shadow-light);
            cursor: pointer;
            transition: box-shadow 0.15s, transform 0.15s;
          }
          .asset-select-card-body {
            display: flex;
            align-items: flex-start;
            gap: 12px;
          }
          .asset-select-icon {
            position: relative;
            flex: 0 0 35%;
            aspect-ratio: 1 / 1;
            border-radius: 12px;
            background: var(--surface);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
          }
          .asset-select-icon img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            padding: 6px;
          }
          .asset-select-icon-placeholder {
            font-size: 12px;
            color: var(--text-soft);
          }
          .asset-status-dot {
            position: absolute;
            top: 10px;
            right: 10px;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            border: 2px solid var(--surface);
            box-shadow: 1px 1px 3px rgba(0,0,0,0.15);
            z-index: 1;
          }
          .asset-select-info {
            flex: 1;
            min-width: 0;
          }
          .asset-select-card:hover {
            transform: translateY(-2px);
            box-shadow: 8px 8px 16px var(--neu-shadow-dark), -8px -8px 16px var(--neu-shadow-light);
          }
          .asset-select-card:active {
            transform: translateY(0);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
          }
          .asset-select-card-disabled {
            cursor: not-allowed;
            opacity: 0.55;
          }
          .asset-select-card-disabled:hover {
            transform: none;
            box-shadow: 6px 6px 12px var(--neu-shadow-dark), -6px -6px 12px var(--neu-shadow-light);
          }
          .asset-select-code {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            text-align: center;
            font-family: var(--mono);
            font-size: 12px;
            font-weight: 700;
            color: #ffffff;
            background: rgba(0,0,0,0.55);
            padding: 3px 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .asset-select-desc {
            font-size: 13px;
            color: var(--text-soft);
            margin-top: 4px;
            min-height: 18px;
            word-break: break-word;
          }
          .asset-select-meta {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
            margin-top: 10px;
          }        

          .review-card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 14px;
          }
          .review-card {
            background: var(--neu-bg);
            border-radius: 16px;
            padding: 16px;
            box-shadow: 6px 6px 12px var(--neu-shadow-dark), -6px -6px 12px var(--neu-shadow-light);
            display: flex;
            flex-direction: column;
            gap: 10px;
          }
          .review-card-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 8px;
          }
          .review-card-code {
            font-family: var(--mono);
            font-size: 15px;
            font-weight: 700;
            color: var(--text);
          }
          .review-card-desc {
            font-size: 12.5px;
            color: var(--text-soft);
            min-height: 16px;
          }
          .review-card-meta-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
            color: var(--text-soft);
            gap: 8px;
          }
          .review-card-issue-count {
            font-family: var(--mono);
            font-weight: 700;
            color: var(--text);
            white-space: nowrap;
          }

          .checks { display: flex; flex-wrap: wrap; gap: 14px; margin: 14px 0; }

          .neu-check {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            cursor: pointer;
            user-select: none;
            position: relative;
          }
          .neu-check-input {
            position: absolute;
            opacity: 0;
            width: 0;
            height: 0;
          }
          .neu-check-box {
            width: 20px;
            height: 20px;
            border-radius: 6px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--neu-bg);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            color: transparent;
            transition: color 0.15s;
          }
          .neu-check-box svg {
            width: 13px;
            height: 13px;
          }
          .neu-check-input:checked + .neu-check-box {
            color: var(--accent);
            box-shadow: 2px 2px 4px var(--neu-shadow-dark), -2px -2px 4px var(--neu-shadow-light);
          }
          .neu-check-input:disabled + .neu-check-box {
            opacity: 0.5;
            cursor: not-allowed;
          }
          .neu-check-input:disabled ~ span {
            color: var(--text-soft);
          }          

          .neu-toggle {
            width: 42px;
            height: 24px;
            border-radius: 12px;
            padding: 0;
            position: relative;
            background: var(--neu-bg);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            flex-shrink: 0;
            transition: box-shadow 0.15s;
          }
          .neu-toggle[data-on="true"] {
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }
          .neu-toggle-knob {
            position: absolute;
            top: 3px;
            left: 3px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: var(--text-soft);
            transition: transform 0.18s, background 0.18s;
          }
          .neu-toggle[data-on="true"] .neu-toggle-knob {
            transform: translateX(18px);
            background: var(--accent);
          }

          .checklist-item-controls {
            display: grid;
            grid-template-columns: 1fr 1fr auto;
            gap: 10px;
            align-items: center;
          }
          .checklist-item-controls select { width: 100%; min-width: 0; }
          .checklist-required-check { font-size: 12px; white-space: nowrap; }

          @container (max-width: 640px) {
            .checklist-item-controls {
              grid-template-columns: 1fr;
              gap: 8px;
            }
            .checklist-required-check { justify-self: start; }
          }          

          .trigger-row {
            display: grid;
            grid-template-columns: 1.3fr 0.6fr 0.8fr 0.8fr 0.8fr 0.7fr 0.5fr;
            align-items: center;
            gap: 8px;
            padding: 12px 4px;
            font-size: 14px;
          }
          .trigger-row + .trigger-row {
            border-top: 1px solid var(--neu-shadow-light);
          }
          .trigger-row.trigger-head {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            color: var(--text-soft);
            font-weight: 600;
          }
          .trigger-readonly {
            font-family: var(--mono);
            color: var(--text-soft);
          }


          .trigger-input {
            width: 100%;
            padding: 9px 11px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-family: var(--sans);
            background: var(--neu-bg);
            color: var(--text);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
          }
          .trigger-input:disabled {
            background: #e9ebed;
            color: #6b7280;
            box-shadow: none;
            cursor: not-allowed;
          }
          .trigger-row .icon-btn:disabled {
            opacity: 0.35;
            cursor: not-allowed;
            box-shadow: none;
          }

          .grid-table { display: flex; flex-direction: column; border-radius: 12px; overflow: hidden; background: var(--neu-bg); box-shadow: inset 2px 2px 5px var(--neu-shadow-dark), inset -2px -2px 5px var(--neu-shadow-light); }
          .grid-row {
            display: grid;
            grid-template-columns: 110px 1fr 90px 90px;
            gap: 12px;
            align-items: center;
            padding: 12px 14px;
            font-size: 14px;
          }

          .grid-row:nth-child(even):not(.grid-head) { background: rgba(0,0,0,0.02); }
          .grid-row:not(.grid-head):hover { background: var(--hover-highlight); }          
          .grid-head {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            color: var(--text-soft);
            font-weight: 600;
            background: rgba(0,0,0,0.03);
          }

          .pagination-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 14px;
            flex-wrap: wrap;
            gap: 10px;
          }
          .pagination-info { font-size: 12px; color: var(--text-soft); font-family: var(--mono); }
          .pagination-controls { display: flex; align-items: center; gap: 4px; }
          .page-btn {
            min-width: 36px;
            height: 36px;
            padding: 0 8px;
            border-radius: 8px;
            font-size: 14px;
            background: var(--neu-bg);
            color: var(--text-soft);
            box-shadow: 3px 3px 6px var(--neu-shadow-dark), -3px -3px 6px var(--neu-shadow-light);
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .page-btn svg { width: 15px; height: 15px; }
          .page-btn:disabled { opacity: 0.35; cursor: not-allowed; box-shadow: none; }
          .page-btn.page-num.active {
            color: #2f6fed;
            font-weight: 700;
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }
          .page-dots { padding: 0 4px; color: var(--text-soft); font-size: 13px; }

          .trigger-row input[type="checkbox"] {
            width: 16px;
            height: 16px;
            accent-color: var(--accent);
            justify-self: start;
          }

          .check { display: flex; align-items: center; gap: 6px; font-size: 14px; cursor: pointer; user-select: none; }
          .check input { accent-color: var(--accent); width: 18px; height: 18px; }

          .actions { display: flex; gap: 8px; margin-top: 16px; }
          button {
            font-family: var(--sans); font-size: 14px; font-weight: 500; border-radius: 10px;
            border: none; padding: 12px 20px; cursor: pointer; transition: box-shadow 0.15s, transform 0.1s;
            background: var(--neu-bg);
            box-shadow: 5px 5px 10px var(--neu-shadow-dark), -5px -5px 10px var(--neu-shadow-light);
          }
          button:active { box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light); transform: translateY(0); }
          button.primary { color: #2f6fed; font-weight: 600; }
          button.ghost { color: var(--text-soft); }
          /* Disabled buttons must look disabled in every theme (macOS themes have their own rule). */
          button:disabled, button:disabled:active { cursor: not-allowed; opacity: 0.45; box-shadow: none; transform: none; }

          .toast {
            margin-top: 12px; padding: 10px 14px; border-radius: 10px; font-size: 13px;
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
          }
          .toast.ok { color: #0f6e56; }
          .toast.err { color: #a32d2d; }

          .table-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 14px; flex-wrap: wrap; }
          .search {
            padding: 12px 16px; border: none; border-radius: 10px; font-size: 14px; width: min(260px, 100%);
            background: var(--neu-bg);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
          }
          .count { font-size: 12px; color: var(--text-soft); font-family: var(--mono); }

          .cards { display: grid; gap: 10px; }
          .card {
            display: grid; grid-template-columns: 1fr auto; gap: 10px; align-items: center;
            border: none; border-radius: 8px; padding: 14px 4px;
            background: transparent;
            box-shadow: none;
          }
          .card + .card {
            border-top: 1px solid var(--neu-shadow-light);
            box-shadow: 0 -1px 0 var(--neu-shadow-dark);
          }
          .card-main { min-width: 0; }
          .code { font-family: var(--mono); font-size: 15px; font-weight: 600; letter-spacing: -0.01em; }
          .desc { font-size: 14px; color: var(--text-soft); margin-top: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
          .meta { display: flex; gap: 8px; margin-top: 6px; flex-wrap: wrap; }
          .pill { font-size: 11px; padding: 2px 8px; border-radius: 20px; font-weight: 500; }
          .pill.active { background: var(--accent-soft); color: var(--accent); }
          .pill.inactive { background: var(--danger-soft); color: var(--danger); }
          .pill.neutral { background: var(--warn-soft); color: var(--warn); }
          .pill.trigger-counter { background: transparent; color: var(--text-soft); }
          .trigger-icon-chip {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 6px;
            border-radius: 10px;
            color: var(--text-soft);
            font-size: 11px;
            font-weight: 600;
            flex-shrink: 0;
          }
          .trigger-icon-chip svg { width: 14px; height: 14px; flex-shrink: 0; }

          .dashboard-bg-wrap { position: relative; }
          .dashboard-bg-layer { position: absolute; inset: -24px -24px -24px -24px; z-index: 0; overflow: hidden; border-radius: 12px; }
          .dashboard-bg-layer img { width: 100%; height: 100%; object-fit: cover; display: block; opacity: 0.16; }
          .dashboard-bg-layer .dashboard-bg-veil {
            position: absolute; inset: 0;
            background: linear-gradient(160deg, var(--surface) 0%, var(--surface) 55%, transparent 100%);
          }
          .dashboard-bg-content { position: relative; z-index: 1; }

          .dashboard-hub-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 16px; margin-top: 18px;
          }
          .dashboard-tile {
            display: flex; flex-direction: column; gap: 10px; align-items: flex-start;
            padding: 20px; border-radius: 14px; border: none; text-align: left;
            background: var(--surface); box-shadow: 6px 6px 14px var(--neu-shadow-dark), -6px -6px 14px var(--neu-shadow-light);
            cursor: pointer; transition: transform 0.12s, box-shadow 0.12s;
          }
          .dashboard-tile:hover { transform: translateY(-2px); }
          .dashboard-tile-icon {
            width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center;
            background: var(--accent-soft); color: var(--accent); flex-shrink: 0;
          }
          .dashboard-tile-icon svg { width: 22px; height: 22px; }
          .dashboard-tile-title { font-size: 15px; font-weight: 600; }
          .dashboard-tile-desc { font-size: 12.5px; color: var(--text-soft); line-height: 1.4; }
          .dashboard-tile.disabled {
            cursor: default; opacity: 0.5; box-shadow: none; border: 1px dashed var(--neu-shadow-dark);
          }
          .dashboard-tile.disabled .dashboard-tile-icon { background: transparent; color: var(--text-soft); }
          .dashboard-tile-badge {
            font-size: 10px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase;
            color: var(--text-soft); background: var(--neu-shadow-light); padding: 2px 8px; border-radius: 20px;
          }

          /* Asset MR-I History screen (asset grid) and its per-asset report timeline
             subscreen -- neumorphic raised cards throughout, scoped so the app's other
             generic list/card styles elsewhere are untouched. */
          .mri-history-grid {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 22px; margin-top: 22px;
          }
          .mri-history-card {
            display: flex; flex-direction: column; gap: 12px;
            background: var(--neu-bg); border: none; border-radius: 18px;
            padding: 24px 26px; cursor: pointer;
            box-shadow: 6px 6px 14px var(--neu-shadow-dark), -6px -6px 14px var(--neu-shadow-light);
            transition: transform 0.15s;
          }
          .mri-history-card:hover { transform: translateY(-2px); }
          .mri-history-card .code { font-size: 17px; }
          .mri-history-card .desc { font-size: 13.5px; line-height: 1.6; }
          .mri-history-card .meta { gap: 10px; }

          .mri-stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px; margin-top: 20px; }
          .mri-stat-card {
            display: flex; align-items: center; gap: 16px;
            background: color-mix(in srgb, var(--neu-bg) 55%, transparent);
            backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
            border-radius: 18px; padding: 18px 22px;
            box-shadow: 6px 6px 14px var(--neu-shadow-dark), -6px -6px 14px var(--neu-shadow-light);
          }
          .mri-stat-icon {
            width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
          }
          .mri-stat-icon svg { width: 22px; height: 22px; }
          .mri-stat-body { flex: 1; min-width: 0; }
          .mri-stat-label { font-size: 12.5px; color: var(--text-soft); font-weight: 600; margin-bottom: 2px; }
          .mri-stat-value { font-size: 22px; font-weight: 700; margin-bottom: 10px; }
          .mri-stat-bar-track { height: 8px; border-radius: 20px; background: var(--neu-shadow-dark); overflow: hidden; }
          .mri-stat-bar-fill { height: 100%; border-radius: 20px; transition: width 0.3s; }
          /* B3: stat cards show a round gauge (running value against the trigger interval). */
          .mri-stat-gauge-card { flex-direction: column; align-items: center; gap: 10px; padding: 16px 18px; }
          .mri-stat-head { display: flex; align-items: center; gap: 10px; align-self: stretch; }
          .mri-stat-head .mri-stat-icon { width: 34px; height: 34px; }
          .mri-stat-head .mri-stat-icon svg { width: 18px; height: 18px; }
          .mri-stat-head .mri-stat-label { margin: 0; }
          .mri-stat-of { font-size: 12px; color: var(--text-soft); font-weight: 600; }
          /* Dashboard KPI cards (replaces the round gauges) */
          .mri-kpi-card { flex-direction: column; align-items: stretch; gap: 12px; padding: 16px 18px; }
          .mri-kpi-head { display: flex; align-items: center; gap: 10px; }
          .mri-kpi-head .mri-stat-icon { width: 34px; height: 34px; }
          .mri-kpi-head .mri-stat-icon svg { width: 18px; height: 18px; }
          .mri-kpi-head .mri-stat-label { margin: 0; flex: 1; min-width: 0; }
          .mri-kpi-pill { display: inline-flex; align-items: center; gap: 6px; font-size: 11.5px; font-weight: 700; padding: 3px 9px; border-radius: 999px; white-space: nowrap; }
          .mri-kpi-pill i { width: 7px; height: 7px; border-radius: 50%; display: block; }
          .mri-kpi-value { font-size: 30px; font-weight: 700; line-height: 1.1; letter-spacing: -0.02em; color: var(--text); font-variant-numeric: tabular-nums; }
          .mri-kpi-unit { font-size: 15px; font-weight: 600; color: var(--text-soft); margin-left: 4px; }
          .mri-kpi-of { display: block; font-size: 12px; font-weight: 500; color: var(--text-soft); letter-spacing: 0; margin-top: 4px; }
          .mri-kpi-track { position: relative; height: 8px; border-radius: 999px; background: var(--chip-bg, rgba(0,0,0,0.08)); overflow: visible; }
          .mri-kpi-fill { height: 100%; border-radius: 999px; transition: width 0.4s ease; }
          .mri-kpi-warn { position: absolute; top: -3px; width: 2px; height: 14px; border-radius: 1px; background: var(--text-soft); opacity: 0.6; transform: translateX(-1px); }
          .mri-kpi-foot { display: flex; justify-content: space-between; font-size: 12px; font-weight: 600; color: var(--text-soft); font-variant-numeric: tabular-nums; }

          .mri-report-timeline { position: relative; margin-top: 28px; padding-left: 34px; }
          .mri-report-timeline::before {
            content: ""; position: absolute; left: 10px; top: 10px; bottom: 10px; width: 2px;
            background: var(--neu-shadow-dark);
          }
          .mri-report-item { position: relative; margin-bottom: 18px; }
          .mri-report-item:last-child { margin-bottom: 0; }
          .mri-report-dot {
            position: absolute; left: -34px; top: 34px; width: 14px; height: 14px; border-radius: 50%;
            box-shadow: 0 0 0 4px var(--neu-bg); z-index: 1;
          }
          .mri-report-card {
            position: relative;
            display: flex; align-items: center; gap: 20px; flex-wrap: wrap;
            background: color-mix(in srgb, var(--neu-bg) 55%, transparent);
            backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
            border-radius: 20px; padding: 34px 24px 20px;
            box-shadow: 6px 6px 14px var(--neu-shadow-dark), -6px -6px 14px var(--neu-shadow-light);
          }
          .mri-report-icon {
            width: 46px; height: 46px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            flex-shrink: 0;
          }
          .mri-report-icon svg { width: 22px; height: 22px; }
          .mri-report-info { display: flex; flex-direction: column; gap: 3px; min-width: 160px; }
          .mri-report-title { font-size: 15px; font-weight: 700; margin-bottom: 2px; }
          .mri-report-meta-line { font-size: 12.5px; color: var(--text-soft); }
          .mri-report-issues-block { display: flex; flex-direction: column; gap: 5px; flex: 1; min-width: 180px; }
          .mri-report-issues { display: flex; align-items: center; gap: 5px; font-size: 12.5px; color: var(--text-soft); margin-top: 2px; }
          .mri-report-issues svg { width: 13px; height: 13px; }
          .mri-report-view-btn {
            flex: 0 0 auto; margin-left: auto; text-align: center; padding: 8px 14px; border-radius: 10px; border: none;
            background: var(--neu-bg); color: var(--text-soft); font-weight: 600; font-size: 12px;
            box-shadow: 3px 3px 8px var(--neu-shadow-dark), -3px -3px 8px var(--neu-shadow-light);
            cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;
            transition: color 0.15s, box-shadow 0.15s;
          }
          .mri-report-view-btn svg { width: 14px; height: 14px; }
          .mri-report-view-btn:hover { color: var(--accent); box-shadow: 2px 2px 6px var(--neu-shadow-dark), -2px -2px 6px var(--neu-shadow-light); }
          .mri-report-readings { position: absolute; top: 12px; right: 20px; display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
          .mri-report-issue-badge {
            display: inline-flex; align-items: center; font-size: 10.5px; font-weight: 700;
            background: var(--danger-soft); color: var(--danger); padding: 1px 8px; border-radius: 20px; margin-left: 6px;
          }
          .mri-report-fields { display: grid; grid-template-columns: auto auto; column-gap: 16px; row-gap: 3px; margin-top: 4px; }
          .mri-report-field-label { font-size: 12.5px; color: var(--text-soft); }
          .mri-report-field-date { display: flex; align-items: center; gap: 5px; font-size: 11.5px; color: var(--text-soft); white-space: nowrap; }
          .mri-report-field-date svg { width: 12px; height: 12px; flex-shrink: 0; }
          .mri-report-key-issue { display: flex; align-items: flex-start; gap: 5px; font-size: 11px; color: var(--danger); margin-top: 4px; }
          .mri-report-key-issue svg { width: 12px; height: 12px; flex-shrink: 0; margin-top: 1px; }
          .card {
            cursor: pointer;
            transition: background 0.12s;
          }
          .card:hover { background: var(--hover-highlight); }

          .card-actions { display: flex; gap: 6px; flex-shrink: 0; }
          .icon-btn {
            width: 38px;
            height: 38px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            background: var(--neu-bg);
            box-shadow: 3px 3px 6px var(--neu-shadow-dark), -3px -3px 6px var(--neu-shadow-light);
            color: var(--text-soft);
          }
          .icon-btn:active {
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }
          .icon-btn svg { width: 19px; height: 19px; color: inherit; }
          .icon-btn.icon-danger svg { color: #a32d2d; }

          .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(231, 234, 240, 0.7);
            backdrop-filter: blur(3px);
            -webkit-backdrop-filter: blur(3px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
            animation: picker-backdrop-in 0.2s ease-out;
          }

          .modal {
            background: var(--neu-bg); border-radius: 20px; padding: 24px; width: min(380px, 90vw);
            box-shadow: 10px 10px 20px var(--neu-shadow-dark), -10px -10px 20px var(--neu-shadow-light);
            opacity: 0;
            transform: scale(0.85);
            animation: orb-in 0.3s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
          }
          
          .modal-icon {
            width: 44px; height: 44px; border-radius: 50%; color: #a32d2d;
            display: flex; align-items: center; justify-content: center; margin-bottom: 12px;
            background: var(--neu-bg);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
          }
          
          .modal h3 { margin: 0 0 10px; font-size: 16px; }
          .modal p { margin: 0 0 18px; font-size: 13px; color: var(--text-soft); line-height: 1.5; }
          .modal-actions { display: flex; justify-content: flex-end; gap: 8px; }
          button.danger { background: var(--danger); color: #ffffff; }
          button.danger:hover { opacity: 0.88; }

          .modal-actions { display: flex; justify-content: flex-end; gap: 8px; }
          button.danger { background: var(--danger); color: #ffffff; }
          button.danger:hover { opacity: 0.88; }

          .graph-modal {
            background: var(--neu-bg);
            border-radius: 20px;
            padding: 20px;
            width: min(1800px, 96vw);
            max-height: 96vh;
            overflow-y: auto;
            box-shadow: 10px 10px 20px var(--neu-shadow-dark), -10px -10px 20px var(--neu-shadow-light);
            opacity: 0;
            transform: scale(0.9);
            animation: orb-in 0.25s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
          }
          
          .graph-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
          }
          .graph-modal-header h3 { margin: 0; font-size: 16px; }         

          .placeholder-screen { text-align: center; padding: 80px 20px; color: var(--text-soft); }
          .placeholder-icon { font-size: 40px; margin-bottom: 12px; }
          .placeholder-screen h2 { font-size: 18px; color: var(--text); margin: 0 0 8px; }
          .placeholder-screen p { font-size: 13px; max-width: 360px; margin: 0 auto; }

          .wizard-steps {
            display: flex;
            align-items: center;
            gap: 4px;
            margin-bottom: 20px;
            flex-wrap: wrap;
          }
          .wizard-step {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            border-radius: 12px;
            font-size: 12.5px;
            color: var(--text-soft);
          }
          .wizard-step-dot {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            background: var(--neu-bg);
            box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light);
            color: var(--text-soft);
            flex-shrink: 0;
          }
          .wizard-step.active { color: var(--text); }
          .wizard-step.active .wizard-step-dot {
            background: var(--accent-blue);
            color: #ffffff;
            box-shadow: none;
          }
          .wizard-step.done .wizard-step-dot {
            background: var(--accent-soft);
            color: var(--accent);
            box-shadow: none;
          }
          .wizard-step-label { white-space: nowrap; }
          @container (max-width: 640px) {
            .wizard-step-label { display: none; }
          }          

          .mri-preview-form {
            background: var(--bg);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 24px;
          }
          .mri-preview-title {
            font-size: 16px;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 4px;
          }
          .mri-preview-section-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: var(--text-soft);
            border-bottom: 2px solid var(--accent-blue);
            display: inline-block;
            padding-bottom: 3px;
            margin-bottom: 12px;
          }
          .mri-preview-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 14px;
          }

          .mri-preview-table {
            display: flex;
            flex-direction: column;
          }
          .mri-preview-table-row {
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 16px;
            align-items: center;
            padding: 8px 0;
          }
          .mri-preview-table-row + .mri-preview-table-row {
            border-top: 1px solid var(--border);
          }
          .mri-preview-table-row label {
            font-size: 12.5px;
            color: var(--text-soft);
            margin-bottom: 0;
          }
          @container (max-width: 500px) {
            .mri-preview-table-row { grid-template-columns: 1fr; gap: 4px; }
          } 

          .mri-preview-mid-grid {
            display: grid;
            grid-template-columns: repeat(2, auto 1fr);
            gap: 10px 16px;
            width: 100%;
            align-items: center;
          }
          .mri-preview-mid-pair {
            display: contents;
          }
          .mri-preview-mid-pair label {
            font-size: 12.5px;
            color: var(--text-soft);
            white-space: nowrap;
          }
          @container (max-width: 500px) {
            .mri-preview-mid-grid { grid-template-columns: 1fr; }
            .mri-preview-mid-pair { display: flex; flex-direction: column; gap: 4px; }
          }

          .mri-review-value {
            font-size: 12.5px;
            font-weight: 600;
            color: var(--text);
          }

          .mri-footer-preview {
            display: flex;
            flex-direction: column;
            gap: 4px;
          }
          .mri-footer-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 0;
            font-size: 13px;
            border-top: 1px solid var(--border);
          }
          .mri-preview-toggle {
            width: 36px;
            height: 20px;
            border-radius: 10px;
            background: var(--neu-shadow-dark);
            position: relative;
          }
          .mri-preview-toggle-knob {
            position: absolute;
            top: 2px;
            left: 2px;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: var(--surface);
          }

          .mri-footer-signoff-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin-top: 10px;
          }
          .mri-footer-signoff-field label {
            display: block;
            font-size: 11.5px;
            color: var(--text-soft);
            margin-bottom: 4px;
          }
          @container (max-width: 700px) {
            .mri-footer-signoff-grid { grid-template-columns: repeat(2, 1fr); }
          }
          @container (max-width: 400px) {
            .mri-footer-signoff-grid { grid-template-columns: 1fr; }
          }          

          .mri-preview-field label {
            display: block;
            font-size: 11.5px;
            color: var(--text-soft);
            margin-bottom: 4px;
          }

          .mri-preview-input {
            height: 30px;
            border: 1px solid var(--border);
            border-radius: 6px;
            background: var(--surface);
          }

          .mri-checklist-table { display: flex; flex-direction: column; }
          .mri-checklist-row {
            display: grid;
            grid-template-columns: 1.6fr 1.2fr 1.2fr 0.8fr 1fr 0.8fr;
            gap: 10px;
            align-items: center;
            padding: 8px 4px;
            font-size: 12.5px;
          }
          .mri-checklist-row + .mri-checklist-row {
            border-top: 1px solid var(--border);
          }
          .mri-checklist-head {
            font-size: 10.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            color: var(--text-soft);
          }
          @container (max-width: 720px) {
            .mri-checklist-row { grid-template-columns: 1fr; gap: 4px; }
            .mri-checklist-head { display: none; }
          }

          .combobox-panel {
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            right: 0;
            z-index: 30;
            max-height: 240px;
            overflow-y: auto;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.12);
            padding: 4px;
          }
          .combobox-option {
            padding: 8px 10px;
            border-radius: 7px;
            font-size: 13px;
            cursor: pointer;
            color: var(--text);
          }
          .combobox-option:hover { background: var(--hover-highlight); }
          .combobox-option.active { background: var(--accent-soft); color: var(--accent); font-weight: 600; }
          .combobox-empty {
            padding: 10px;
            font-size: 12.5px;
            color: var(--text-soft);
            text-align: center;
          }          

          .admin-layout {
            display: flex;
            gap: 20px;
            align-items: flex-start;
          }
          @container (max-width: 640px) {
            .admin-layout { flex-direction: column; }
          }

          .admin-sidebar {
            width: clamp(210px, 24cqi, 280px);
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
            gap: 8px;
            background: var(--neu-bg);
            border-radius: 20px;
            padding: clamp(10px, 2cqi, 16px);
            box-shadow: 8px 8px 16px var(--neu-shadow-dark), -8px -8px 16px var(--neu-shadow-light);
          }

          @container (max-width: 640px) {
            .admin-sidebar {
              width: 100%;
              flex-direction: row;
              flex-wrap: wrap;
            }
            .admin-group { flex: 1; min-width: 140px; }
            .admin-group-body-inner { padding-left: 12px; }
          }

          .admin-group { margin-bottom: 4px; }

          .admin-group-header {
            width: 100%;
            display: flex;
            align-items: center;
            gap: 10px;
            background: transparent;
            border: none;
            border-radius: 14px;
            padding: 12px 10px;
            font-size: clamp(14px, 2.8cqi, 15px);
            font-weight: 600;
            color: var(--text-soft);
            cursor: pointer;
            box-shadow: none;
            text-align: left;
            transition: background 0.15s, color 0.15s;
          }
          .admin-group-header:hover { background: rgba(0,0,0,0.03); }
          .admin-group-header:active { box-shadow: none; transform: none; }
          .admin-group-header.highlight { color: var(--text); }

          .admin-group-label { flex: 1; }

          .admin-chevron {
            width: 15px;
            height: 15px;
            flex-shrink: 0;
            color: var(--text-soft);
            transition: transform 0.2s ease;
          }
          .admin-chevron.open { transform: rotate(90deg); }

          .admin-group-body {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.22s ease;
          }
          .admin-group-body.open { max-height: 400px; }
          .admin-group-body-inner {
            display: flex;
            flex-direction: column;
            gap: 3px;
            padding-left: 34px;
            padding-top: 2px;
            padding-bottom: 4px;
          }

          .admin-child-item {
            display: flex;
            align-items: center;
            gap: 9px;
            text-align: left;
            background: transparent;
            border: none;
            border-radius: 10px;
            padding: 10px 12px;
            font-size: 14px;
            font-weight: 500;
            color: var(--text-soft);
            cursor: pointer;
            box-shadow: none;
            transition: background 0.12s, box-shadow 0.12s, color 0.12s;
          }
          .admin-child-icon {
            width: 26px;
            height: 26px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: inherit;
          }
          .admin-child-icon svg { width: 16px; height: 16px; }
          .admin-child-item:hover { background: rgba(0,0,0,0.03); }
          .admin-child-item:active { box-shadow: none; transform: none; }
          .admin-child-item.active {
            background: var(--neu-bg);
            color: #2f6fed;
            box-shadow: inset 2px 2px 4px var(--neu-shadow-dark), inset -2px -2px 4px var(--neu-shadow-light);
          }

          .admin-nav-icon {
            width: 40px;
            height: 40px;
            flex-shrink: 0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2f6fed;
            background: var(--neu-bg);
            box-shadow: inset 4px 4px 8px var(--neu-shadow-dark), inset -4px -4px 8px var(--neu-shadow-light);
          }
          .admin-nav-icon svg { width: 19px; height: 19px; }

          .admin-content { flex: 1; min-width: 0; min-height: 340px; }          



          .liquid-scene {
            position: relative;
            min-height: 640px;
            border-radius: 24px;
            overflow: hidden;
            background: linear-gradient(160deg, #0d1b3a, #1a2f5c 55%, #0d1b3a);
          }
          .liquid-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(50px);
            opacity: 0.75;
            mix-blend-mode: screen;
          }
          .liquid-blob-a {
            width: 320px; height: 320px;
            background: radial-gradient(circle, #6ea8ff, transparent 70%);
            top: -60px; left: -60px;
            animation: liquid-float-a 14s ease-in-out infinite;
          }
          .liquid-blob-b {
            width: 280px; height: 280px;
            background: radial-gradient(circle, #a06eff, transparent 70%);
            bottom: -40px; right: 10%;
            animation: liquid-float-b 18s ease-in-out infinite;
          }
          .liquid-blob-c {
            width: 240px; height: 240px;
            background: radial-gradient(circle, #6effd6, transparent 70%);
            top: 30%; right: -60px;
            animation: liquid-float-c 16s ease-in-out infinite;
          }
          @keyframes liquid-float-a {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(60px, 80px) scale(1.15); }
          }
          @keyframes liquid-float-b {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-50px, -60px) scale(1.1); }
          }
          @keyframes liquid-float-c {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(-70px, 40px) scale(0.9); }
          }

          .liquid-content {
            position: relative;
            z-index: 1;
            padding: 40px clamp(20px, 4vw, 48px);
            display: flex;
            flex-wrap: wrap;
            gap: 24px;
            align-items: flex-start;
          }

          .glass-card {
            width: min(460px, 100%);
            padding: 28px;
            border-radius: 20px;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.25);
            backdrop-filter: blur(18px);
            -webkit-backdrop-filter: blur(18px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.25);
            color: #ffffff;
          }
          .glass-card-small { width: min(300px, 100%); padding: 20px; }

          .glass-title { font-size: 18px; font-weight: 600; margin: 0 0 8px; }
          .glass-text { font-size: 13px; color: rgba(255,255,255,0.75); line-height: 1.5; margin: 0 0 18px; }
          .glass-label { font-size: 12px; color: rgba(255,255,255,0.75); }

          .glass-tabs { display: flex; gap: 4px; margin-bottom: 18px; padding: 4px; background: rgba(0,0,0,0.15); border-radius: 12px; }
          .glass-tab {
            flex: 1; background: transparent; border: none; color: rgba(255,255,255,0.7);
            padding: 7px 10px; font-size: 12px; border-radius: 9px; cursor: pointer; transition: background 0.15s, color 0.15s;
          }
          .glass-tab.active { background: rgba(255,255,255,0.22); color: #ffffff; }

          .glass-field { margin-bottom: 16px; display: flex; flex-direction: column; gap: 6px; }
          .glass-input {
            width: 100%; padding: 10px 12px; border-radius: 10px; font-size: 13px; font-family: var(--sans);
            background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.25); color: #ffffff;
          }
          .glass-input::placeholder { color: rgba(255,255,255,0.5); }
          .glass-input:focus { outline: none; border-color: rgba(255,255,255,0.6); background: rgba(255,255,255,0.16); }
          .glass-textarea { min-height: 70px; resize: vertical; }
          select.glass-input option { color: #1a1d1f; }

          .glass-row { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; gap: 12px; }

          .glass-toggle {
            width: 42px; height: 24px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.3);
            background: rgba(255,255,255,0.12); position: relative; cursor: pointer; padding: 0; transition: background 0.15s;
          }
          .glass-toggle.on { background: rgba(110,168,255,0.7); }
          .glass-toggle-knob {
            position: absolute; top: 2px; left: 2px; width: 18px; height: 18px; border-radius: 50%;
            background: #ffffff; transition: transform 0.18s;
          }
          .glass-toggle.on .glass-toggle-knob { transform: translateX(18px); }

          .glass-slider {
            flex: 1; -webkit-appearance: none; height: 4px; border-radius: 2px;
            background: rgba(255,255,255,0.25); outline: none;
          }
          .glass-slider::-webkit-slider-thumb {
            -webkit-appearance: none; width: 16px; height: 16px; border-radius: 50%;
            background: #ffffff; cursor: pointer; box-shadow: 0 0 0 4px rgba(255,255,255,0.15);
          }

          .glass-check-row { display: flex; align-items: center; gap: 8px; font-size: 13px; color: rgba(255,255,255,0.88); cursor: pointer; margin-bottom: 8px; }
          .glass-checkbox, .glass-radio { width: 16px; height: 16px; accent-color: #ffffff; cursor: pointer; }

          .glass-progress { width: 100%; height: 8px; border-radius: 4px; background: rgba(255,255,255,0.15); overflow: hidden; }
          .glass-progress-fill { height: 100%; background: linear-gradient(90deg, #6ea8ff, #a06eff); transition: width 0.15s; }

          .glass-actions { display: flex; flex-wrap: wrap; gap: 10px; }
          .glass-button {
            padding: 10px 18px; border-radius: 10px; font-size: 13px; font-weight: 500; cursor: pointer;
            border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.14); color: #ffffff;
            backdrop-filter: blur(6px); transition: background 0.15s;
          }
          .glass-button:hover { background: rgba(255,255,255,0.22); }
          .glass-button-primary { background: rgba(110,168,255,0.55); border-color: rgba(110,168,255,0.7); }
          .glass-button-primary:hover { background: rgba(110,168,255,0.7); }
          .glass-button-danger { background: rgba(255,110,110,0.4); border-color: rgba(255,110,110,0.6); }
          .glass-button-danger:hover { background: rgba(255,110,110,0.55); }
          .glass-button-icon { width: 40px; height: 40px; padding: 0; display: flex; align-items: center; justify-content: center; }
          .glass-button-icon svg { width: 18px; height: 18px; }

          .glass-badge {
            display: inline-block; margin-top: 12px; padding: 4px 10px; font-size: 11px; font-weight: 600;
            border-radius: 20px; background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3);
          }
          
          .status-screen { text-align: center; padding: 80px 20px; }
          .status-badge {
            position: relative;
            width: 96px;
            height: 96px;
            margin: 0 auto 24px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .status-ring {
            position: absolute;
            inset: 0;
            border-radius: 50%;
            background: conic-gradient(from 0deg, #2f6fed 0deg, #2f6fed 90deg, transparent 90deg, transparent 360deg);
            animation: status-spin 2.4s linear infinite;
            -webkit-mask: radial-gradient(farthest-side, transparent calc(100% - 5px), #000 calc(100% - 5px));
            mask: radial-gradient(farthest-side, transparent calc(100% - 5px), #000 calc(100% - 5px));
          }
          .status-core {
            position: relative;
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #2f6fed;
            background: var(--neu-bg);
            box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light);
            animation: status-pulse 2.8s ease-in-out infinite;
          }
          .status-screen h2 { font-size: 18px; color: var(--text); margin: 0 0 8px; font-weight: 600; }
          .status-screen p { font-size: 13px; color: var(--text-soft); max-width: 340px; margin: 0 auto; line-height: 1.5; }

          @keyframes status-spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          @keyframes status-pulse {
            0%, 100% { box-shadow: inset 5px 5px 10px var(--neu-shadow-dark), inset -5px -5px 10px var(--neu-shadow-light); }
            50% { box-shadow: inset 3px 3px 6px var(--neu-shadow-dark), inset -3px -3px 6px var(--neu-shadow-light); }
          }

          @page {
            size: A4;
            margin: 0;
          }
          @media print {
            .no-print, .ui-nav, .wizard-steps, .actions,
            .side-drawer-handle, .theme-fab, .uilab-fab, .current-user-banner {
              display: none !important;
            }
            body * { visibility: hidden; }
            .print-area, .print-area * { visibility: visible; }
            .print-area {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
            }
            .panel { box-shadow: none; background: #fff; padding: 0; }
            .mri-preview-section-label { break-after: avoid; }
            .mri-preview-table-row, .mri-checklist-row { break-inside: avoid; }
            /* MR-I report PDF: each .mri-report-page is a full A4 sheet -- force a hard
               page break after every one except the last so the browser's print-to-PDF
               (window.print(), no jsPDF/html2canvas involved) lays out page 1 (dashboard)
               and page 2 (checklist) as separate PDF pages instead of flowing together. */
            .mri-report-page {
              width: 210mm !important;
              min-height: 297mm !important;
              max-width: 210mm !important;
              page-break-after: always;
              break-after: page;
              overflow: hidden;
            }
            .mri-report-page:last-child {
              page-break-after: auto;
              break-after: auto;
            }
          }
          /* ===== macOS themes: ported from the UI Lab macOS sample (MacOsTest.tsx) ===== */
          [data-theme="macos"] {
            --bg: #ffffff; --tab-track: rgba(120,120,128,0.18); --chip-bg: rgba(120,120,128,0.2); --neu-bg: #f6f6f6; --neu-shadow-dark: transparent; --neu-shadow-light: transparent;
            --surface: #ffffff; --border: rgba(0,0,0,0.12); --row: rgba(0,0,0,0.035); --ctl: #ffffff; --field: #ffffff;
            --bar: #ececef; --side: rgba(236,236,240,0.82); --field-border: rgba(0,0,0,0.28);
            --text: #1d1d1f; --text-soft: #6e6e73;
            --accent: #0a84ff; --accent-soft: rgba(0,122,255,0.12); --accent-blue: #0a84ff; --accent-blue-deep: #0a6cdc;
            --chart-violet: #af52de; --chart-green: #34c759; --hover-highlight: rgba(0,122,255,0.10);
            --warn: #b25000; --warn-soft: #fff1dc; --danger: #d70015; --danger-soft: #ffe5e8; --success: #1f8a3d; --success-soft: #e2f6e8;
            --radius: 10px;
            --field-h: 24px; --field-px: 8px; --select-pr: 26px; --neu-inset: inset 0 0 0 1px var(--border); --neu-inset-deep: inset 0 0 0 1px var(--border); --neu-inset-sm: inset 0 0 0 1px var(--border); --neu-inset-well: inset 0 0 0 1px var(--border); --neu-raised: 0 0 0 1px var(--border), 0 0.5px 1.5px rgba(0,0,0,0.12); --neu-raised-sm: 0 0 0 1px var(--border), 0 0.5px 1.5px rgba(0,0,0,0.12); --seg-pad: 3px 14px; --seg-radius: 6px; --seg-font: 12px; --seg-on-weight: 600; --seg-off-weight: 400; --seg-on-bg: var(--ctl); --seg-on-color: var(--text); --seg-off-color: var(--text); --seg-on-shadow: 0 0.5px 1.5px rgba(0,0,0,0.3), 0 0 0 0.5px rgba(0,0,0,0.04); --seg-track-radius: 8px; --seg-track-pad: 2px; --seg-border: 0;
            --sans: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", "Segoe UI", system-ui, sans-serif;
          }
          [data-theme="macos-dark"] {
            --bg: #1e1e20; --neu-bg: #28282a; --neu-shadow-dark: transparent; --neu-shadow-light: transparent;
            --surface: #2a2a2d; --border: rgba(255,255,255,0.10); --row: rgba(255,255,255,0.04); --ctl: #4a4a4f; --field: #2a2a2d;
            --bar: #2b2b2e; --side: rgba(44,44,48,0.78); --field-border: rgba(255,255,255,0.24);
            --text: #f2f2f4; --text-soft: #9a9aa2;
            --accent: #0a84ff; --accent-soft: rgba(10,132,255,0.22); --accent-blue: #0a84ff; --accent-blue-deep: #4da3ff;
            --chart-violet: #bf5af2; --chart-green: #30d158; --hover-highlight: rgba(10,132,255,0.22);
            --warn: #ff9f0a; --warn-soft: #3a2c10; --danger: #ff453a; --danger-soft: #3d1c1a; --success: #30d158; --success-soft: #153a22;
            --radius: 10px;
            --field-h: 24px; --field-px: 8px; --select-pr: 26px; --neu-inset: inset 0 0 0 1px var(--border); --neu-inset-deep: inset 0 0 0 1px var(--border); --neu-inset-sm: inset 0 0 0 1px var(--border); --neu-inset-well: inset 0 0 0 1px var(--border); --neu-raised: 0 0 0 1px var(--border), 0 0.5px 1.5px rgba(0,0,0,0.12); --neu-raised-sm: 0 0 0 1px var(--border), 0 0.5px 1.5px rgba(0,0,0,0.12); --seg-pad: 3px 14px; --seg-radius: 6px; --seg-font: 12px; --seg-on-weight: 600; --seg-off-weight: 400; --seg-on-bg: var(--ctl); --seg-on-color: var(--text); --seg-off-color: var(--text); --seg-on-shadow: 0 0.5px 1.5px rgba(0,0,0,0.3), 0 0 0 0.5px rgba(0,0,0,0.04); --seg-track-radius: 8px; --seg-track-pad: 2px; --seg-border: 0;
            --sans: -apple-system, BlinkMacSystemFont, "SF Pro Text", "Helvetica Neue", "Segoe UI", system-ui, sans-serif;
            --hero-veil: linear-gradient(100deg, rgba(30,30,32,0.94) 0%, rgba(30,30,32,0.82) 30%, rgba(30,30,32,0.45) 65%, rgba(30,30,32,0.15) 100%);
            --glass-bg: rgba(44,44,48,0.6); --glass-bg-strong: rgba(44,44,48,0.8); --text-halo: none;
            --tab-track: rgba(120,120,128,0.3); --chip-bg: rgba(120,120,128,0.3); --disabled-bg: #3a3a3c;
          }
          [data-theme="macos"] .app, .app[data-theme="macos"] { color-scheme: light; }
          .app[data-theme="macos-dark"] { color-scheme: dark; }

          /* base type and density: 13px, tight tracking, no zoom */
          .app[data-theme^="macos"] { zoom: 1; height: 100vh; width: 100vw; font-family: var(--sans); font-size: 13px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .content { background: var(--bg); }

          /* groups: panels, tiles, cards (mac-group) */
          .app[data-theme^="macos"] .panel, .app[data-theme^="macos"] .menu-card, .app[data-theme^="macos"] .review-card, .app[data-theme^="macos"] .toast {
            background: var(--row); border: 1px solid var(--border); border-radius: 10px; box-shadow: none;
          }
          .app[data-theme^="macos"] .panel { padding: 16px; }
          .app[data-theme^="macos"] .panel.panel-flat { background: transparent; }
          .app[data-theme^="macos"] .panel h2 { font-size: 13px; font-weight: 600; text-transform: none; letter-spacing: -0.01em; color: var(--text); margin: 0 0 10px; }
          .app[data-theme^="macos"] .card { border: 0; border-top: 1px solid var(--border); border-radius: 0; padding: 10px 14px; background: transparent; box-shadow: none; }
          .app[data-theme^="macos"] .card:first-child { border-top: 0; }
          .app[data-theme^="macos"] .pill { font-size: 11px; }

          /* push buttons (mac-btn) */
          .app[data-theme^="macos"] button:not(.theme-fab):not(.glass-button):not(.mr-level-btn):not(.page-btn):not(.side-drawer-handle):not(.neu-toggle):not(.menu-card):not(.uilab-fab):not(.icon-btn):not(.drawer-nav-btn):not(.admin-group-header):not(.admin-child-item):not(.theme-option) {
            font-family: var(--sans); font-size: 13px; font-weight: 400; letter-spacing: -0.01em; color: var(--text);
            padding: 3px 14px; min-height: 22px; background: var(--ctl); border: 1px solid var(--border); border-radius: 6px;
            box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); cursor: default; transition: none;
          }
          .app[data-theme^="macos"] button:not(.theme-fab):not(.glass-button):not(.mr-level-btn):not(.page-btn):not(.side-drawer-handle):not(.neu-toggle):not(.menu-card):not(.uilab-fab):not(.icon-btn):not(.drawer-nav-btn):not(.admin-group-header):not(.admin-child-item):not(.theme-option):active { filter: brightness(0.92); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); transform: none; }
          .app[data-theme^="macos"] button.primary:not(.theme-fab):not(.glass-button):not(.mr-level-btn) {
            color: #fff; font-weight: 400; border-color: #0a6cdc; background: linear-gradient(180deg, #3d9dff, #0a7cff);
          }
          .app[data-theme^="macos"] button.ghost:not(.theme-fab):not(.glass-button):not(.mr-level-btn) { color: var(--text); }
          .app[data-theme^="macos"] button:disabled { opacity: 0.45; }

          /* icon buttons: compact square control, icon stays readable */
          .app[data-theme^="macos"] button.icon-btn {
            width: 28px; height: 28px; min-height: 0; padding: 0; display: inline-flex; align-items: center; justify-content: center;
            background: var(--ctl); border: 1px solid var(--border); border-radius: 6px; box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22);
            color: var(--text); cursor: default; transition: none;
          }
          .app[data-theme^="macos"] button.icon-btn:active { filter: brightness(0.92); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); transform: none; }
          .app[data-theme^="macos"] button.icon-btn svg { width: 17px; height: 17px; color: inherit; }
          .app[data-theme^="macos"] button.icon-btn.icon-danger { color: var(--danger); }
          .app[data-theme^="macos"] button.icon-btn.icon-danger svg { color: var(--danger); }

          /* fields (mac-input) and popups (mac-popup) */
          .app[data-theme^="macos"] input:not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="range"]):not([type="button"]):not([type="submit"]):not(.neu-check-input),
          .app[data-theme^="macos"] textarea, .app[data-theme^="macos"] .field input:not([type="checkbox"]):not([type="radio"]):not([type="file"]):not([type="range"]) {
            font: inherit; letter-spacing: -0.01em; color: var(--text); background: var(--field); border: 1px solid var(--field-border);
            border-radius: 6px; padding: 4px 8px; outline: none; box-shadow: 0 0.5px 1px rgba(0,0,0,0.12) inset;
          }
          .app[data-theme^="macos"] select, .app[data-theme^="macos"] .field select {
            appearance: none; -webkit-appearance: none; font: inherit; letter-spacing: -0.01em; color: var(--text);
            padding: 3px 26px 3px 10px; background-color: var(--ctl); border: 1px solid var(--field-border); border-radius: 6px;
            box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.2);
            background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='18' height='18'><rect width='18' height='18' rx='4' fill='%230a84ff'/><path d='M5.5 7.5L9 4.5l3.5 3M5.5 10.5L9 13.5l3.5-3' fill='none' stroke='white' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/></svg>"); background-repeat: no-repeat; background-size: 18px 18px; background-position: right 3px center;
          }
          .app[data-theme^="macos"] input:focus, .app[data-theme^="macos"] textarea:focus, .app[data-theme^="macos"] select:focus, .app[data-theme^="macos"] .field input:focus, .app[data-theme^="macos"] .field select:focus {
            border-color: #0a84ff; box-shadow: 0 0 0 3.5px rgba(10,132,255,0.35); outline: none;
          }
          .app[data-theme^="macos"] input:disabled, .app[data-theme^="macos"] textarea:disabled, .app[data-theme^="macos"] select:disabled { opacity: 0.5; box-shadow: none; }

          /* switches (mac-switch) */
          .app[data-theme^="macos"] .neu-toggle {
            width: 38px; height: 22px; border-radius: 11px; border: 0; padding: 0; min-height: 0; position: relative;
            background: rgba(120,120,128,0.32); box-shadow: none; transition: background 160ms; cursor: default;
          }
          .app[data-theme^="macos"] .neu-toggle[data-on="true"] { background: #34c759; box-shadow: none; }
          .app[data-theme^="macos"] .neu-toggle-knob { top: 2px; left: 2px; width: 18px; height: 18px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.3); transition: transform 160ms; }
          .app[data-theme^="macos"] .neu-toggle[data-on="true"] .neu-toggle-knob { transform: translateX(16px); background: #fff; }

          /* checkboxes (mac-check) */
          .app[data-theme^="macos"] .neu-check { gap: 8px; font-size: 13px; line-height: 16px; cursor: default; }
          .app[data-theme^="macos"] .neu-check-box { width: 16px; height: 16px; border-radius: 4px; background: var(--field); border: 1px solid rgba(120,120,128,0.55); box-shadow: none; }
          .app[data-theme^="macos"] .neu-check-box svg { width: 11px; height: 11px; }
          .app[data-theme^="macos"] .neu-check-input:checked + .neu-check-box { background: #0a84ff; border-color: #0a84ff; color: #fff; box-shadow: none; }

          /* tables (mac-table) */
          .app[data-theme^="macos"] .grid-table { background: transparent; border: 1px solid var(--border); border-radius: 10px; box-shadow: none; }
          .app[data-theme^="macos"] .grid-row { padding: 6px 12px; font-size: 12.5px; gap: 12px; }
          .app[data-theme^="macos"] .grid-row:nth-child(even):not(.grid-head) { background: var(--row); }
          .app[data-theme^="macos"] .grid-row:not(.grid-head):hover { background: var(--hover-highlight); }
          .app[data-theme^="macos"] .grid-head { font-size: 12.5px; font-weight: 500; text-transform: none; letter-spacing: -0.01em; color: var(--text-soft); background: transparent; border-bottom: 1px solid var(--border); }

          /* sheets / dialogs (mac-sheet) */
          .app[data-theme^="macos"] .modal {
            background: var(--side); backdrop-filter: blur(30px) saturate(1.6); border: 1px solid var(--border);
            border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.35);
          }
          .app[data-theme^="macos"] .modal h3 { font-size: 13px; font-weight: 600; margin: 8px 0 4px; }
          .app[data-theme^="macos"] .modal p { font-size: 11.5px; color: var(--text-soft); }
          /* A3a: Main Menu tiles (grouped tile with a blue app icon, like the sample sheet) */
          .app[data-theme^="macos"] .menu-grid { gap: 14px; }
          .app[data-theme^="macos"] .menu-card { padding: 16px 14px; min-height: clamp(120px, 18vh, 170px); transition: background 0.12s; cursor: default; }
          .app[data-theme^="macos"] .menu-card:hover { transform: none; box-shadow: none; background: var(--hover-highlight); }
          .app[data-theme^="macos"] .menu-card:active { transform: none; box-shadow: none; filter: brightness(0.95); }
          .app[data-theme^="macos"] .menu-icon-wrap {
            width: 44px; height: 44px; margin: 0 auto 10px; border-radius: 11px; color: #fff;
            background: linear-gradient(180deg, #3d9dff, #0a7cff); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.25);
          }
          .app[data-theme^="macos"] .menu-card:hover .menu-icon-wrap, .app[data-theme^="macos"] .menu-card:active .menu-icon-wrap { color: #fff; }
          .app[data-theme^="macos"] .menu-icon-wrap svg { width: 24px; height: 24px; }
          .app[data-theme^="macos"] .menu-card h3 { font-size: 13px; font-weight: 600; margin: 0 0 4px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .menu-card p { font-size: 11.5px; line-height: 1.35; color: var(--text-soft); }
          /* A3b: side drawer (frosted sidebar) and the user handle at the screen edge */
          .app[data-theme^="macos"] .side-drawer-overlay { background: rgba(0,0,0,0.12); }
          .app[data-theme^="macos"] .side-drawer {
            background: var(--side); backdrop-filter: blur(24px) saturate(1.6); -webkit-backdrop-filter: blur(24px) saturate(1.6);
            border-left: 1px solid var(--border); box-shadow: -8px 0 30px rgba(0,0,0,0.22); padding: 14px 10px; gap: 12px;
          }
          .app[data-theme^="macos"] .drawer-user-card { padding: 10px 12px; border-radius: 10px; background: var(--row); border: 1px solid var(--border); box-shadow: none; }
          .app[data-theme^="macos"] .drawer-user-name { font-size: 13px; font-weight: 600; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .drawer-user-role { font-size: 11.5px; margin-top: 2px; }
          .app[data-theme^="macos"] .drawer-section-label { font-size: 11px; font-weight: 600; letter-spacing: 0; text-transform: none; margin: 4px 8px 2px; }
          .app[data-theme^="macos"] .drawer-nav-btn {
            padding: 5px 8px; border-radius: 6px; border: 0; background: transparent; box-shadow: none; min-height: 0;
            color: var(--text); font-size: 13px; font-weight: 400; letter-spacing: -0.01em; gap: 8px; cursor: default;
          }
          .app[data-theme^="macos"] .drawer-nav-btn:hover { background: rgba(120,120,128,0.14); color: var(--text); }
          .app[data-theme^="macos"] .drawer-nav-btn:active { background: var(--accent-blue); color: #fff; }
          .app[data-theme^="macos"] .drawer-nav-btn svg { width: 15px; height: 15px; color: var(--accent-blue); }
          .app[data-theme^="macos"] .drawer-nav-btn:active svg { color: #fff; }
          .app[data-theme^="macos"] .side-drawer-handle:not(.side-drawer-handle-avatar) { border: 1px solid var(--border); border-right: 0; background: var(--side); backdrop-filter: blur(24px); box-shadow: none; }
          .app[data-theme^="macos"] .drawer-handle-avatar-circle { box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.3); }
          .app[data-theme^="macos"] .drawer-handle-avatar-info { background: var(--side); backdrop-filter: blur(24px) saturate(1.6); border: 1px solid var(--border); border-left: 0; border-radius: 0 10px 10px 0; box-shadow: 0 1px 4px rgba(0,0,0,0.12); }
          .app[data-theme^="macos"] .side-drawer-handle-name { font-size: 13px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .side-drawer-handle-role { font-size: 11px; }
          /* A3c: Administration left navigation (sidebar list, blue selected row) */
          .app[data-theme^="macos"] .admin-layout { gap: 16px; }
          .app[data-theme^="macos"] .admin-sidebar {
            background: var(--side); backdrop-filter: blur(24px) saturate(1.6); -webkit-backdrop-filter: blur(24px) saturate(1.6);
            border: 1px solid var(--border); border-radius: 10px; box-shadow: none; padding: 10px; gap: 2px; width: clamp(190px, 22cqi, 240px);
          }
          .app[data-theme^="macos"] .admin-group { margin-bottom: 2px; }
          .app[data-theme^="macos"] .admin-group-header {
            padding: 5px 8px; border-radius: 6px; border: 0; background: transparent; box-shadow: none; min-height: 0;
            font-size: 13px; font-weight: 600; letter-spacing: -0.01em; color: var(--text); gap: 8px; cursor: default;
          }
          .app[data-theme^="macos"] .admin-group-header:hover { background: rgba(120,120,128,0.14); }
          .app[data-theme^="macos"] .admin-group-header.highlight { color: var(--text); }
          .app[data-theme^="macos"] .admin-nav-icon { width: 18px; height: 18px; border-radius: 0; background: transparent; box-shadow: none; color: var(--accent-blue); }
          .app[data-theme^="macos"] .admin-nav-icon svg { width: 15px; height: 15px; }
          .app[data-theme^="macos"] .admin-chevron { width: 12px; height: 12px; }
          .app[data-theme^="macos"] .admin-group-body-inner { padding-left: 22px; gap: 1px; }
          .app[data-theme^="macos"] .admin-child-item {
            padding: 5px 8px; border-radius: 6px; border: 0; background: transparent; box-shadow: none; min-height: 0;
            font-size: 13px; font-weight: 400; letter-spacing: -0.01em; color: var(--text); gap: 8px; cursor: default;
          }
          .app[data-theme^="macos"] .admin-child-item:hover { background: rgba(120,120,128,0.14); }
          .app[data-theme^="macos"] .admin-child-item.active { background: var(--accent-blue); color: #fff; box-shadow: none; }
          .app[data-theme^="macos"] .admin-child-icon { width: 16px; height: 16px; color: var(--accent-blue); }
          .app[data-theme^="macos"] .admin-child-icon svg { width: 15px; height: 15px; }
          .app[data-theme^="macos"] .admin-child-item.active .admin-child-icon { color: #fff; }
          /* A3d: wizard steps and MR level buttons (tab strips use the --seg-* variables above) */
          .app[data-theme^="macos"] .wizard-steps { gap: 2px; margin-bottom: 14px; }
          .app[data-theme^="macos"] .wizard-step { padding: 4px 8px; border-radius: 6px; font-size: 12px; gap: 6px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .wizard-step-dot { width: 20px; height: 20px; font-size: 11px; background: rgba(120,120,128,0.18); box-shadow: none; color: var(--text-soft); }
          .app[data-theme^="macos"] .wizard-step.active { color: var(--text); font-weight: 600; }
          .app[data-theme^="macos"] .wizard-step.active .wizard-step-dot { background: var(--accent-blue); color: #fff; }
          .app[data-theme^="macos"] .wizard-step.done .wizard-step-dot { background: var(--accent-soft); color: var(--accent-blue); }
          .app[data-theme^="macos"] .mr-level-row { height: 30px; margin-top: 10px; }
          .app[data-theme^="macos"] .mr-level-btn {
            width: 30px; height: 30px; font-size: 12px; font-weight: 600; color: var(--accent-blue); background: var(--ctl);
            border: 1px solid var(--border); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); cursor: default;
          }
          .app[data-theme^="macos"] .mr-level-btn:hover { box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); background: var(--hover-highlight); }
          .app[data-theme^="macos"] .mr-level-btn:active { filter: brightness(0.92); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); }
          /* A3e: pagination, theme button and picker (search box is covered by the field rules) */
          .app[data-theme^="macos"] .pagination-bar { margin-top: 10px; gap: 8px; }
          .app[data-theme^="macos"] .page-btn {
            min-width: 26px; height: 22px; padding: 0 8px; border-radius: 6px; font-size: 12px; color: var(--text);
            background: var(--ctl); border: 1px solid var(--border); box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); cursor: default;
          }
          .app[data-theme^="macos"] .page-btn:active:not(:disabled) { filter: brightness(0.92); }
          .app[data-theme^="macos"] .page-btn:disabled { opacity: 0.4; box-shadow: none; }
          .app[data-theme^="macos"] .page-btn.page-num.active { color: #fff; font-weight: 600; border-color: #0a6cdc; background: linear-gradient(180deg, #3d9dff, #0a7cff); box-shadow: none; }
          .app[data-theme^="macos"] .page-dots { font-size: 12px; }
          .app[data-theme^="macos"] .theme-fab {
            width: 32px; height: 32px; color: var(--text); background: var(--ctl); border: 1px solid var(--border);
            box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); cursor: default;
          }
          .app[data-theme^="macos"] .theme-fab:hover { color: var(--accent-blue); transform: none; }
          .app[data-theme^="macos"] .theme-fab:active { box-shadow: 0 0.5px 1.5px rgba(0,0,0,0.22); transform: none; filter: brightness(0.92); }
          .app[data-theme^="macos"] .theme-fab svg { width: 16px; height: 16px; }
          .app[data-theme^="macos"] .theme-picker {
            bottom: 60px; gap: 1px; padding: 5px; border-radius: 10px; background: var(--side);
            backdrop-filter: blur(30px) saturate(1.6); -webkit-backdrop-filter: blur(30px) saturate(1.6);
            border: 1px solid var(--border); box-shadow: 0 10px 30px rgba(0,0,0,0.35);
          }
          .app[data-theme^="macos"] .theme-option {
            padding: 4px 10px; border-radius: 5px; border: 0; background: transparent; box-shadow: none; min-height: 0;
            color: var(--text); font-size: 13px; font-weight: 400; letter-spacing: -0.01em; gap: 8px; cursor: default;
          }
          .app[data-theme^="macos"] .theme-option:hover { background: var(--accent-blue); color: #fff; }
          .app[data-theme^="macos"] .gate-theme-picker { border-radius: 8px; padding: 3px; border: 1px solid var(--border); box-shadow: 0 4px 14px rgba(0,0,0,0.18); }
          .app[data-theme^="macos"] .theme-option.active { box-shadow: none; font-weight: 600; }
          .app[data-theme^="macos"] .theme-swatch { width: 14px; height: 14px; box-shadow: inset 0 0 0 0.5px rgba(0,0,0,0.25); }
          /* A4a: Dashboard tiles, history cards, stat cards, report timeline.
             Also replaces places that used the (transparent here) shadow colours as fills or dividers. */
          .app[data-theme^="macos"] .dashboard-hub-grid { gap: 12px; margin-top: 14px; }
          .app[data-theme^="macos"] .dashboard-tile { padding: 14px; border-radius: 10px; border: 1px solid var(--border); background: var(--row); box-shadow: none; gap: 8px; cursor: default; transition: background 0.12s; }
          .app[data-theme^="macos"] .dashboard-tile:hover { transform: none; background: var(--hover-highlight); }
          .app[data-theme^="macos"] .dashboard-tile-icon { width: 34px; height: 34px; border-radius: 8px; background: var(--accent-soft); color: var(--accent-blue); }
          .app[data-theme^="macos"] .dashboard-tile-icon svg { width: 19px; height: 19px; }
          .app[data-theme^="macos"] .dashboard-tile-title { font-size: 13px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .dashboard-tile-desc { font-size: 11.5px; }
          .app[data-theme^="macos"] .dashboard-tile.disabled { box-shadow: none; border: 1px dashed var(--border); background: transparent; }
          .app[data-theme^="macos"] .dashboard-tile-badge { background: var(--chip-bg); }
          .app[data-theme^="macos"] .mri-history-grid { gap: 12px; margin-top: 14px; }
          .app[data-theme^="macos"] .mri-history-card { background: var(--row); border: 1px solid var(--border); border-radius: 10px; padding: 14px 16px; box-shadow: none; gap: 8px; cursor: default; transition: background 0.12s; }
          .app[data-theme^="macos"] .mri-history-card:hover { transform: none; background: var(--hover-highlight); }
          .app[data-theme^="macos"] .mri-history-card .code { font-size: 14px; }
          .app[data-theme^="macos"] .mri-history-card .desc { font-size: 12px; line-height: 1.45; }
          .app[data-theme^="macos"] .mri-stat-grid { gap: 10px; margin-top: 14px; }
          .app[data-theme^="macos"] .mri-stat-card, .app[data-theme^="macos"] .mri-report-card {
            background: var(--row); backdrop-filter: none; -webkit-backdrop-filter: none;
            border: 1px solid var(--border); border-radius: 10px; box-shadow: none;
          }
          .app[data-theme^="macos"] .mri-stat-card { padding: 12px 14px; gap: 12px; }
          .app[data-theme^="macos"] .mri-report-card { padding: 28px 16px 14px; gap: 14px; }
          .app[data-theme^="macos"] .mri-stat-bar-track { background: var(--chip-bg); }
          .app[data-theme^="macos"] .mri-report-timeline::before { background: var(--border); }
          .app[data-theme^="macos"] .mri-report-dot { box-shadow: 0 0 0 4px var(--bg); }
          .app[data-theme^="macos"] .mri-preview-toggle { background: var(--chip-bg); }
          .app[data-theme^="macos"] .trigger-row + .trigger-row, .app[data-theme^="macos"] .card + .card { border-top: 1px solid var(--border); box-shadow: none; }
          .app[data-theme^="macos"] .build-ground { stroke: var(--border); }
          /* A4b: Main Menu KPI strip. The red-to-green gauge colours are kept (they carry meaning); the frame is flat. */
          .app[data-theme^="macos"] .kpi-footer { background: var(--bg); border-top: 1px solid var(--border); padding: 10px 0 0; gap: 10px; }
          .app[data-theme^="macos"] .kpi-footer-item { padding: 8px 12px; gap: 4px; border-radius: 10px; background: var(--row); border: 1px solid var(--border); box-shadow: none; cursor: default; min-width: 140px; transition: background 0.12s; }
          .app[data-theme^="macos"] .kpi-footer-item:hover { transform: none; background: var(--hover-highlight); box-shadow: none; }
          .app[data-theme^="macos"] .kpi-footer-item:active { transform: none; box-shadow: none; filter: brightness(0.95); }
          .app[data-theme^="macos"] .kpi-footer-label { font-size: 11px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .kpi-footer-value { font-family: var(--sans); font-variant-numeric: tabular-nums; font-size: 16px; font-weight: 600; letter-spacing: -0.02em; }
          .app[data-theme^="macos"] .kpi-footer-delta { font-family: var(--sans); font-variant-numeric: tabular-nums; font-size: 11px; }
          .app[data-theme^="macos"] .kpi-footer-delta.good { color: var(--success); }
          .app[data-theme^="macos"] .kpi-gauge-track { height: 5px; border-radius: 3px; }
          .app[data-theme^="macos"] .kpi-gauge-mask { background: #e3e3e6; box-shadow: none; }
          .app[data-theme="macos-dark"] .kpi-gauge-mask { background: #3a3a3c; }
          /* A4c: trigger rows and inputs, form labels, list text */
          .app[data-theme^="macos"] .field { margin-bottom: 10px; }
          .app[data-theme^="macos"] .field label { font-size: 12px; margin-bottom: 3px; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .trigger-row { padding: 8px 4px; font-size: 13px; gap: 8px; }
          .app[data-theme^="macos"] .trigger-row.trigger-head { font-size: 12px; text-transform: none; letter-spacing: -0.01em; font-weight: 500; }
          .app[data-theme^="macos"] .trigger-readonly { font-family: var(--sans); font-variant-numeric: tabular-nums; }
          .app[data-theme^="macos"] .trigger-input { width: 100%; font-size: 13px; }
          .app[data-theme^="macos"] .trigger-input:disabled { background: var(--disabled-bg); color: var(--text-soft); opacity: 1; }
          .app[data-theme^="macos"] .neu-select { width: 100%; }
          .app[data-theme^="macos"] .code { font-family: var(--sans); font-size: 13px; font-weight: 600; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .desc { font-size: 12px; }
          .app[data-theme^="macos"] .mri-preview-form { border-radius: 10px; padding: 16px; }
          .app[data-theme^="macos"] .mri-preview-section-label { font-size: 11px; font-weight: 600; text-transform: none; letter-spacing: 0; }
          .app[data-theme^="macos"] .mri-preview-input { height: 24px; border-radius: 6px; }
          /* A4d (self-review): sunken/raised wells become hairline outlines via the --neu-* variables above;
             permission/country tiles keep their on/off tint but use the macOS radius. */
          .app[data-theme^="macos"] [role="switch"]:not(.neu-toggle), .app[data-theme^="macos"] [role="radio"] { border-radius: 10px !important; cursor: default !important; }
          /* A4d (checked in a headless render of the real stylesheet): destructive buttons and review-card text */
          /* macOS: the Fail button (and other danger buttons) use a pale red fill with red text. */
          .app[data-theme="macos"] button.danger:not(.theme-fab):not(.glass-button):not(.mr-level-btn) { background: #fbd9d6 !important; color: #b3140b !important; box-shadow: inset 0 0 0 1px rgba(215,0,21,0.25) !important; }
          .app[data-theme="macos-dark"] button.danger:not(.theme-fab):not(.glass-button):not(.mr-level-btn) { background: rgba(255,69,58,0.22) !important; color: #ff6961 !important; box-shadow: inset 0 0 0 1px rgba(255,69,58,0.35) !important; }
          .app[data-theme^="macos"] button.danger:not(.theme-fab):not(.glass-button):not(.mr-level-btn):hover { filter: brightness(0.97); }
          .app[data-theme^="macos"] .review-card-code { font-family: var(--sans); font-size: 13px; font-weight: 600; letter-spacing: -0.01em; }
          .app[data-theme^="macos"] .review-card-desc { font-size: 12px; }
          /* B1: shared instruments (Instruments.tsx). Skeuomorphic base for Light/Dark and the other themes. */
          .instr-lamp { --lamp-size: 18px; display: inline-flex; align-items: center; gap: 6px; vertical-align: middle; font-size: 11px; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text-soft); }
          .instr-lamp i { width: var(--lamp-size); height: var(--lamp-size); flex: none; border-radius: 50%; display: block; border: max(1.5px, calc(var(--lamp-size) * 0.1)) solid #8b9199; box-shadow: 0 2px 4px rgba(0,0,0,0.55), 0 0 0 1px #4a4f56; }
          .instr-lamp.off i { background: radial-gradient(circle at 35% 30%, #5b6068, #2b2e33); }
          .instr-lamp.red i { background: radial-gradient(circle at 35% 30%, #ffd6d1, #ff3b2f 45%, #b3140b); box-shadow: 0 0 calc(var(--lamp-size) * 0.45) calc(var(--lamp-size) * 0.1) rgba(255,59,47,0.8), 0 2px 4px rgba(0,0,0,0.55); }
          .instr-lamp.yellow i { background: radial-gradient(circle at 35% 30%, #fff3c2, #ffc928 45%, #b88a05); box-shadow: 0 0 calc(var(--lamp-size) * 0.45) calc(var(--lamp-size) * 0.1) rgba(255,201,40,0.8), 0 2px 4px rgba(0,0,0,0.55); }
          .instr-lamp.green i { background: radial-gradient(circle at 35% 30%, #d9ffe0, #36d65a 45%, #0e8a2d); box-shadow: 0 0 calc(var(--lamp-size) * 0.45) calc(var(--lamp-size) * 0.1) rgba(54,214,90,0.8), 0 2px 4px rgba(0,0,0,0.55); }
          .instr-lamp-text { line-height: 1; }
          .instr-gauge { max-width: 100%; border-radius: 14px; padding: 7px; background: linear-gradient(160deg, #3b3f45, #15171a); box-shadow: 0 8px 14px rgba(0,0,0,0.45), 0 1px 0 rgba(255,255,255,0.35) inset; box-sizing: border-box; }
          .instr-gauge svg { display: block; width: 100%; height: auto; border-radius: 9px; }
          /* B1: macOS themes get a flatter instrument: flat lamp with a soft ring, slim light bezel on the gauge. */
          .app[data-theme^="macos"] .instr-lamp i { border: 0; box-shadow: inset 0 0 0 1px rgba(0,0,0,0.18); }
          .app[data-theme^="macos"] .instr-lamp.off i { background: var(--st-grey); }
          .app[data-theme^="macos"] .instr-lamp.red i { background: var(--st-red); box-shadow: inset 0 0 0 1px rgba(0,0,0,0.15), 0 0 0 calc(var(--lamp-size) * 0.14) color-mix(in srgb, var(--st-red) 25%, transparent); }
          .app[data-theme^="macos"] .instr-lamp.yellow i { background: #ffcc00; box-shadow: inset 0 0 0 1px rgba(0,0,0,0.15), 0 0 0 calc(var(--lamp-size) * 0.14) rgba(255,204,0,0.28); }
          .app[data-theme^="macos"] .instr-lamp.green i { background: var(--st-green); box-shadow: inset 0 0 0 1px rgba(0,0,0,0.15), 0 0 0 calc(var(--lamp-size) * 0.14) color-mix(in srgb, var(--st-green) 25%, transparent); }
          .app[data-theme^="macos"] .instr-lamp { font-weight: 600; letter-spacing: 0; text-transform: none; font-size: 12px; }
          .app[data-theme^="macos"] .instr-gauge { padding: 4px; border-radius: 12px; background: var(--neu-bg); box-shadow: inset 0 0 0 1px var(--border); }
        `}</style>

          <UserPickerGate theme={theme} onThemeChange={handleThemeChange}>
            {screen !== "menu" && (
              <div className="ui-nav">
                <button
                  className="ghost"
                  onClick={() => setScreen("menu")}
                  style={{ padding: "6px 12px", fontSize: 12 }}
                >
                  ← Back to main menu
                </button>
                {showUserBadge && <UserBadge />}
              </div>
            )}

            <div className="content">
              <div
                key={screen}
                className={`screen-fade ${screen === "menu" ? "fixed-height" : ""}`}
              >
                {screen === "menu" && (
                  <MainMenu
                    onNavigate={handleNavigate}
                    currentTheme={theme}
                    onThemeChange={handleThemeChange}
                  />
                )}
                {screen === "assets" && (
                  <AssetRegistry onViewTriggers={handleViewTriggers} onShowAssetFlow={handleOpenAssetFlow} />
                )}
                {screen === "reports" && mrLevel === "MR-I" && (
                  <SelectAssetForReport onReportCreated={handleReportCreated} />
                )}
                {screen === "reports" && mrLevel !== "MR-I" && (
                  <MaintenanceReport />
                )}
                {screen === "report-wizard" && selectedReportId !== null && (
                  <ReportWizard
                    reportId={selectedReportId}
                    onBack={() => setScreen(reportWizardOrigin)}
                    viewOnly={viewOnlyReport}
                    onShowFlow={handleOpenFlow}
                  />
                )}
                {screen === "report-flow" && currentFlow?.type === "report" && (
                  <ReportFlow
                    reportId={currentFlow.id}
                    onBack={handleFlowBack}
                    onOpenReport={(id) => handleReportCreated(id, true)}
                    onNavigate={(target) => setScreen(target)}
                    onShowAssetFlow={handleOpenAssetFlow}
                    onShowReportFlow={handleOpenFlow}
                  />
                )}
                {screen === "asset-flow" && currentFlow?.type === "asset" && (
                  <AssetFlow
                    assetId={currentFlow.id}
                    onBack={handleFlowBack}
                    onOpenReport={(id) => handleReportCreated(id, true)}
                    onShowReportFlow={handleOpenFlow}
                    onOpenAssets={() => setScreen("assets")}
                    onViewTriggers={handleViewTriggers}
                  />
                )}
                {screen === "dashboard" && (
                  <Dashboard
                    onOpenReport={(id) => handleReportCreated(id, true)}
                    onShowAssetFlow={handleOpenAssetFlow}
                    theme={theme}
                    nav={dashboardNav}
                    onNavChange={setDashboardNav}
                  />
                )}
                {screen === "admin" && (
                  <Administration
                    onOpenTemplate={handleOpenTemplate}
                    active={adminActive}
                    setActive={setAdminActive}
                    openGroup={adminOpenGroup}
                    setOpenGroup={setAdminOpenGroup}
                    selectedTemplateId={selectedTemplate?.id ?? null}
                  />
                )}
                {screen === "triggers" && selectedAsset && (
                  <MaintenanceTriggers
                    assetId={selectedAsset.id}
                    assetCode={selectedAsset.code}
                    onBack={() => setScreen("assets")}
                  />
                )}
                {screen === "uilab" && <UiLab />}
                {screen === "distance-map-test" && <DistanceMapTest />}
                {screen === "pending-approvals" && <PendingApprovals onOpenFlow={handleOpenFlow} />}
                {screen === "rectification-queue" && <RectificationQueue onOpenFlow={handleOpenFlow} />}
                {screen === "report-review-queue" && (
                  <ReportReviewQueue onOpenReport={handleReportCreated} onOpenFlow={handleOpenFlow} />
                )}
                {screen === "my-reports-queue" && (
                  <MyReportsQueue onOpenReport={handleReportCreated} onOpenFlow={handleOpenFlow} />
                )}
                {screen === "template-builder" && selectedTemplate && (
                  <TemplateBuilder
                    templateId={selectedTemplate.id}
                    templateName={selectedTemplate.name}
                    onBack={() => {
                      setAdminActive("mri-template");
                      setAdminOpenGroup("mr-templates");
                      setScreen("admin");
                    }}
                  />
                )}
              </div>
            </div>
          </UserPickerGate>
        </div>
      </CurrentUserProvider>
    </QueryClientProvider>
  );
}

export default App;
