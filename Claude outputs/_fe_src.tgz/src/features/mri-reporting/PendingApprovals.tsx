import { useState } from "react";
import ErrorDialog from "../../components/ErrorDialog";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { invoke } from "../../lib/ipc";
import { useCurrentUser } from "../../lib/currentUser";
import { useEffectivePermissions } from "../administration/hooks/useUserAdmin";
import {
    usePendingMriFaultApprovals,
    useProvisionalMriFaultApprovals,
    usePendingMriFaultAcknowledgments,
    useAcknowledgeMriFaultDecision,
    useAssignableMriReviewers,
    useSendFaultReminder,
    type PendingFaultApprovalRow,
    type ProvisionalFaultApprovalRow,
    type PendingFaultAcknowledgmentRow,
} from "./hooks/useMriFaultApprovals";

const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
// dd/Mmm/yyyy. Accepts epoch seconds/milliseconds or a date string.
function formatDate(raw: string | number | null | undefined): string {
    if (raw === null || raw === undefined || String(raw).trim() === "") return "—";
    const n = Number(raw);
    const d = !isNaN(n) ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(raw));
    if (isNaN(d.getTime())) return String(raw);
    return `${String(d.getDate()).padStart(2, "0")}/${MONTH_ABBR[d.getMonth()]}/${d.getFullYear()}`;
}

const SEVERITY_COLOR: Record<string, string> = {
    Minor: "#d4ac0d",
    Moderate: "#d97706",
    Critical: "#c0392b",
};

const REVIEW_METHODS = ["In-Person", "Phone"] as const;
const SEVERITIES = ["Minor", "Moderate", "Critical"] as const;

// A Critical fault requires FSM/Maintenance Manager authority (mri.approve).
// A Moderate fault can be reviewed by an Operations Coordinator / Maintenance
// Supervisor (mri.close_defect) or by anyone with the broader mri.approve right.
function hasDirectAuthority(row: PendingFaultApprovalRow, permissions: string[]) {
    if (row.original_severity === "Critical") return permissions.includes("mri.approve");
    if (row.original_severity === "Moderate") {
        return permissions.includes("mri.close_defect") || permissions.includes("mri.approve");
    }
    return false;
}

// A Job Supervisor without direct authority can still phone a decision in on the real
// authority's behalf (mri.record_provisional) — that entry is always recorded Phone /
// Provisional and needs the real authority's name, since recordedBy != reviewer here.
function canRelay(permissions: string[]) {
    return permissions.includes("mri.record_provisional");
}

type DecisionKind = "Approved" | "Reclassified" | "Rejected" | "Carryforward";

interface PendingApprovalsProps {
    onOpenFlow?: (reportId: number) => void;
}

function PendingApprovals({ onOpenFlow }: PendingApprovalsProps) {
    const { user } = useCurrentUser();
    const { data: permissions = [] } = useEffectivePermissions(user?.id ?? 0);
    const { data: rows = [], isLoading } = usePendingMriFaultApprovals(user?.id ?? 0);
    const { data: provisionalRows = [] } = useProvisionalMriFaultApprovals(user?.id ?? 0);
    const { data: acknowledgmentRows = [] } = usePendingMriFaultAcknowledgments(user?.id ?? 0);
    const canConfirm = permissions.includes("mri.confirm_provisional");
    const canAcknowledge = permissions.includes("mri.acknowledge_critical");
    const qc = useQueryClient();
    const acknowledge = useAcknowledgeMriFaultDecision();

    const [reviewingId, setReviewingId] = useState<number | null>(null);
    const reviewingRow = rows.find((r) => r.id === reviewingId) ?? null;
    // Roster of real review authorities (Maintenance Supervisor / FSM) eligible to be
    // named as who a relayed decision is actually for — scoped to the fault's own
    // asset country so the picker only offers people who could legitimately review it.
    const { data: assignableReviewers = [] } = useAssignableMriReviewers(
        ["mri.close_defect", "mri.approve"],
        reviewingRow?.country ?? null,
    );
    // Stage 3: who a Moderate fault escalated to Critical goes to (FSM / Maintenance Manager).
    const { data: criticalReviewers = [] } = useAssignableMriReviewers(
        ["mri.approve"],
        reviewingRow?.country ?? null,
    );
    // Stage 4: who should be informed of a reviewed Moderate decision.
    const { data: ackCandidates = [] } = useAssignableMriReviewers(
        ["mri.acknowledge_critical"],
        reviewingRow?.country ?? null,
    );
    const [nextReviewerId, setNextReviewerId] = useState("");
    const [ackUserId, setAckUserId] = useState("");
    const sendReminder = useSendFaultReminder();
    const canRemind = permissions.includes("mri.approve");
    const [reviewMethod, setReviewMethod] = useState<(typeof REVIEW_METHODS)[number]>("In-Person");
    const [newSeverity, setNewSeverity] = useState<(typeof SEVERITIES)[number]>("Minor");
    const [notes, setNotes] = useState("");
    const [reviewerName, setReviewerName] = useState("");
    const [status, setStatus] = useState<{ msg: string; kind: "ok" | "err" } | null>(null);

    const decide = useMutation({
        mutationFn: (item: {
            id: number;
            decision: DecisionKind;
            newSeverity: string | null;
            reviewer: string;
            reviewMethod: string;
            notes: string | null;
            recordedBy: string;
            isProvisional: boolean;
            nextReviewerUserId?: number | null;
            acknowledgmentAssignedToUserId?: number | null;
        }) => invoke<string>("set_mri_fault_approval_decision", item),
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: ["pending-mri-fault-approvals"] });
            qc.invalidateQueries({ queryKey: ["pending-mri-fault-acknowledgments"] });
        },
    });

    // Confirms a phoned-in decision (from either queue below) — this only completes the
    // paper trail, since the decision already took effect (closure/tag) when recorded.
    const confirm = useMutation({
        mutationFn: (item: { id: number; confirmedBy: string }) =>
            invoke<string>("confirm_provisional_approval", item),
        onSuccess: () => {
            qc.invalidateQueries({ queryKey: ["provisional-mri-fault-approvals"] });
            qc.invalidateQueries({ queryKey: ["pending-mri-fault-approvals"] });
        },
    });

    async function confirmEntry(row: ProvisionalFaultApprovalRow) {
        if (!user) return;
        try {
            await confirm.mutateAsync({ id: row.id, confirmedBy: user.name });
            flash(`Confirmed — ${row.checklist_description ?? "item"} on ${row.asset_code ?? "asset"}`, "ok");
        } catch (err) {
            flash(String(err), "err");
        }
    }

    async function acknowledgeEntry(row: PendingFaultAcknowledgmentRow) {
        if (!user) return;
        try {
            await acknowledge.mutateAsync({ id: row.id, acknowledgedBy: user.name });
            flash(`Acknowledged — ${row.checklist_description ?? "item"} on ${row.asset_code ?? "asset"}`, "ok");
        } catch (err) {
            flash(String(err), "err");
        }
    }

    // Errors open a modal dialog the user must acknowledge; confirmations stay a short toast.
    const [errorDialog, setErrorDialog] = useState<string | null>(null);
    function flash(msg: string, kind: "ok" | "err") {
        if (kind === "err") {
            setErrorDialog(msg.replace(/^Error:\s*/, ""));
            return;
        }
        setStatus({ msg, kind });
        setTimeout(() => setStatus(null), 5000);
    }

    function startReview(row: PendingFaultApprovalRow, relay: boolean) {
        setReviewingId(row.id);
        // Reviewing directly in the app defaults to In-Person (the reviewer may switch to
        // Phone); recording on someone else's behalf (phone relay) is always Phone.
        setReviewMethod(relay ? "Phone" : "In-Person");
        setNewSeverity(row.original_severity === "Critical" ? "Moderate" : "Minor");
        setNotes("");
        setNextReviewerId("");
        setAckUserId("");
        setReviewerName(relay ? "" : (user?.name ?? ""));
    }

    async function remind(row: PendingFaultApprovalRow) {
        if (!user) return;
        try {
            await sendReminder.mutateAsync({ approvalId: row.id, sentByUserId: user.id });
            flash(`Reminder sent to ${row.assigned_to_name ?? "the reviewer"}`, "ok");
        } catch (err) {
            flash(String(err), "err");
        }
    }

    // A phoned-in decision (Phone method) is always Provisional — it takes effect
    // immediately (closure/tag), and the real authority confirms it later purely to
    // formalize the paper trail. recordedBy is always whoever is physically entering
    // it; reviewer is the authority whose decision it actually is — the same person
    // unless this is a Job Supervisor relay.
    async function submitDecision(row: PendingFaultApprovalRow, decision: DecisionKind, relay: boolean) {
        if (!user) return;
        const reviewer = relay ? reviewerName.trim() : user.name;
        if (relay && !reviewer) {
            flash("Enter the name of the authority you're recording this decision for.", "err");
            return;
        }
        if (!notes.trim()) {
            flash("Notes are required to record a decision.", "err");
            return;
        }
        const escalating =
            decision === "Reclassified" && row.original_severity === "Moderate" && newSeverity === "Critical";
        if (escalating && !nextReviewerId) {
            flash("Select the Maintenance Manager / FSM this Critical fault goes to.", "err");
            return;
        }
        try {
            await decide.mutateAsync({
                id: row.id,
                decision,
                newSeverity: decision === "Reclassified" ? newSeverity : null,
                reviewer,
                reviewMethod: relay ? "Phone" : reviewMethod,
                notes: notes.trim(),
                recordedBy: user.name,
                isProvisional: relay,
                nextReviewerUserId: escalating ? Number(nextReviewerId) : null,
                acknowledgmentAssignedToUserId:
                    row.original_severity === "Moderate" && !escalating && ackUserId ? Number(ackUserId) : null,
            });
            flash(`${decision} — ${row.checklist_description ?? "item"} on ${row.asset_code ?? "asset"}`, "ok");
            setReviewingId(null);
        } catch (err) {
            flash(String(err), "err");
        }
    }

    return (
        <div>
            <style>{`
                .pa-card{gap:12px;min-width:0}
                .pa-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
                .pa-title{font-size:15px;font-weight:600;line-height:1.3;color:var(--text);min-width:0;overflow-wrap:anywhere}
                .pa-sev{flex:none;font-size:11px;font-weight:700;padding:3px 10px;border-radius:999px;color:var(--on-status);white-space:nowrap;margin-top:1px}
                .pa-meta{display:flex;flex-wrap:wrap;gap:4px 6px;font-size:12px;color:var(--text-soft)}
                .pa-meta span{white-space:nowrap;padding:2px 8px;border-radius:999px;border:1px solid var(--border)}
                .pa-dl{display:grid;grid-template-columns:minmax(0,1fr);gap:2px;margin:0;padding:10px 0 0;border-top:1px solid var(--border)}
                .pa-dl dt{font-size:10.5px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:var(--text-soft)}
                .pa-dl dd{margin:0 0 8px;font-size:12.5px;line-height:1.45;color:var(--text)}
                .pa-dl dd:last-child{margin-bottom:0}
                .review-card-grid:has(.pa-card){grid-template-columns:repeat(auto-fill,minmax(300px,1fr));align-items:stretch}
                .pa-note{font-size:11.5px;color:var(--text-soft)}
                .pa-remind{font-weight:600;color:var(--st-amber)}
                .pa-foot{margin-top:auto;padding-top:12px;border-top:1px solid var(--border);display:flex;flex-direction:column;align-items:stretch;gap:12px}
                .pa-assignee{display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--text);min-width:0}
                .pa-assignee small{display:block;font-size:10.5px;color:var(--text-soft);text-transform:uppercase;letter-spacing:.04em}
                .pa-avatar{flex:none;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font-size:12px;font-weight:700;background:var(--accent-soft);color:var(--accent-blue, var(--accent))}
                .pa-btns{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
                .pa-sm{padding:7px 14px;font-size:12.5px}
            `}</style>
            <div className="header">
                <h1>Pending Approvals</h1>
                <span className="sub">Moderate and Critical faults awaiting review or reclassification</span>
            </div>

            {status && <div className={`toast ${status.kind}`} style={{ maxWidth: 600, marginBottom: 16 }}>{status.msg}</div>}
            {errorDialog && <ErrorDialog message={errorDialog} onClose={() => setErrorDialog(null)} />}

            {isLoading ? (
                <p style={{ color: "var(--text-soft)", fontSize: 13 }}>Loading...</p>
            ) : rows.length === 0 ? (
                <p style={{ color: "var(--text-soft)", fontSize: 13 }}>No faults are currently pending approval.</p>
            ) : (
                <div className="review-card-grid">
                {rows.map((row) => {
                        const direct = hasDirectAuthority(row, permissions);
                        const relayOnly = !direct && canRelay(permissions);
                        const allowed = (direct || relayOnly) && row.can_act;
                        return (
                            <div key={row.id} className="review-card pa-card">
                                <div className="pa-head">
                                    <div className="pa-title">{row.checklist_description ?? "Checklist item"}</div>
                                    <span className="pa-sev" style={{ background: SEVERITY_COLOR[row.original_severity] }}>
                                        {row.original_severity}
                                    </span>
                                </div>
                                <div className="pa-meta">
                                    <span>{row.asset_code ?? "Unknown asset"}</span>
                                    <span>Report #{row.report_id}</span>
                                    <span>Reported {formatDate(row.created_date)}</span>
                                </div>

                                {(row.issue_details || row.action_taken) && (
                                    <dl className="pa-dl">
                                        {row.issue_details && (<><dt>Issue</dt><dd>{row.issue_details}</dd></>)}
                                        {row.action_taken && (<><dt>Action taken</dt><dd>{row.action_taken}</dd></>)}
                                    </dl>
                                )}

                                {row.last_reminder_at && (
                                    <div className="pa-note pa-remind">
                                        Reminder from {row.last_reminder_by ?? "a manager"} · {formatDate(row.last_reminder_at)}
                                    </div>
                                )}
                                {!allowed && (
                                    <div className="pa-note">
                                        {row.can_act
                                            ? "You don't have the required permission to review this item."
                                            : `Read-only — waiting on ${row.assigned_to_name ?? "the assigned reviewer"}.`}
                                    </div>
                                )}

                                <div className="pa-foot">
                                    <div className="pa-assignee">
                                        <span className="pa-avatar">{(row.assigned_to_name ?? "?").trim().charAt(0).toUpperCase()}</span>
                                        <span>
                                            <small>Assigned to</small>
                                            {row.assigned_to_name ?? "Anyone with review authority"}
                                        </span>
                                    </div>
                                    <div className="pa-btns">
                                        {onOpenFlow && (
                                            <button className="ghost pa-sm" onClick={() => onOpenFlow(row.report_id)}>Show flow</button>
                                        )}
                                        {!row.can_act && canRemind && row.assigned_to_user_id !== null && (
                                            <button className="ghost pa-sm" onClick={() => remind(row)}>Send Reminder</button>
                                        )}
                                        {allowed && (
                                            <button className="primary pa-sm" onClick={() => startReview(row, !direct)}>
                                                {direct ? "Review" : "Record (Phone Relay)"}
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {canConfirm && provisionalRows.length > 0 && (
                <div style={{ marginTop: 32 }}>
                    <div className="header">
                        <h1>Awaiting Confirmation</h1>
                        <span className="sub">Phoned-in decisions already in effect — confirming only completes the paper trail</span>
                    </div>
                    <div className="review-card-grid">
                        {provisionalRows.map((row) => (
                            <div key={row.id} className="review-card pa-card">
                                <div className="pa-head">
                                    <div className="pa-title">{row.checklist_description ?? "Checklist item"}</div>
                                </div>
                                <div className="pa-meta">
                                    <span>{row.asset_code ?? "Unknown asset"}</span>
                                    <span>Report #{row.report_id}</span>
                                </div>
                                <dl className="pa-dl">
                                    <dt>Decision</dt><dd>{row.decision} by {row.reviewer ?? "Unknown"}</dd>
                                    <dt>Recorded</dt><dd>by {row.recorded_by ?? "Unknown"} on {formatDate(row.created_date)}</dd>
                                </dl>
                                <div className="pa-foot">
                                    <div className="pa-btns">
                                        {onOpenFlow && (
                                            <button className="ghost pa-sm" onClick={() => onOpenFlow(row.report_id)}>Show flow</button>
                                        )}
                                        <button className="primary pa-sm" onClick={() => confirmEntry(row)}>Confirm</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {reviewingId !== null && (() => {
                const row = rows.find((r) => r.id === reviewingId);
                if (!row) return null;
                const direct = hasDirectAuthority(row, permissions);
                const relayOnly = !direct && canRelay(permissions);
                return (
                    <div className="modal-overlay">
                        <div
                            className="modal"
                            style={{
                                width: "min(640px, 94vw)",
                                minHeight: 420,
                                textAlign: "left",
                                borderTop: `6px solid ${SEVERITY_COLOR[row.original_severity]}`,
                            }}
                        >
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
                                <h3 style={{ margin: 0 }}>{row.checklist_description ?? "Checklist item"}</h3>
                                <span
                                    style={{
                                        fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 20,
                                        color: "var(--on-status)", background: SEVERITY_COLOR[row.original_severity], whiteSpace: "nowrap",
                                    }}
                                >
                                    {row.original_severity}
                                </span>
                            </div>
                            <p style={{ marginBottom: 4 }}>
                                Asset: {row.asset_code ?? "Unknown"} · Reported {formatDate(row.created_date)}
                            </p>
                            {row.issue_details && (
                                <p style={{ marginBottom: 4 }}><strong>Issue:</strong> {row.issue_details}</p>
                            )}
                            {row.action_taken && (
                                <p style={{ marginBottom: 12 }}><strong>Action Taken:</strong> {row.action_taken}</p>
                            )}
                            {relayOnly && (
                                <p style={{ fontSize: 11.5, color: "var(--text-soft)", marginBottom: 12 }}>
                                    Recording this call on the authority's behalf — always logged as Phone / Provisional
                                    and will need their confirmation later.
                                </p>
                            )}
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                                <div className="field">
                                    <label>Review Method</label>
                                    {relayOnly ? (
                                        <input
                                            type="text"
                                            className="trigger-input"
                                            value="Phone"
                                            disabled
                                            title="A decision recorded on the authority's behalf is always logged as Phone"
                                        />
                                    ) : (
                                        <select
                                            className="neu-select"
                                            value={reviewMethod}
                                            onChange={(e) => setReviewMethod(e.target.value as (typeof REVIEW_METHODS)[number])}
                                        >
                                            {REVIEW_METHODS.map((m) => (
                                                <option key={m} value={m}>{m}</option>
                                            ))}
                                        </select>
                                    )}
                                </div>
                                <div className="field">
                                    <label>Reclassify To (if applicable)</label>
                                    <select
                                        className="neu-select"
                                        value={newSeverity}
                                        onChange={(e) => setNewSeverity(e.target.value as typeof newSeverity)}
                                    >
                                        {SEVERITIES.map((s) => <option key={s} value={s}>{s === "Critical" ? "Major / Critical" : s}</option>)}
                                    </select>
                                </div>
                            </div>
                            {row.original_severity === "Moderate" && newSeverity === "Critical" && (
                                <div className="field">
                                    <label>Send Critical fault to (Maintenance Manager / FSM) — required when reclassifying to Major / Critical</label>
                                    <select
                                        className="neu-select"
                                        value={nextReviewerId}
                                        onChange={(e) => setNextReviewerId(e.target.value)}
                                    >
                                        <option value="">Select who reviews it next…</option>
                                        {criticalReviewers.map((u) => (
                                            <option key={u.id} value={u.id}>
                                                {u.name} ({u.role})
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            {row.original_severity === "Moderate" && newSeverity !== "Critical" && ackCandidates.length > 0 && (
                                <div className="field">
                                    <label>Inform (optional) — Maintenance Manager / FSM to acknowledge this decision</label>
                                    <select
                                        className="neu-select"
                                        value={ackUserId}
                                        onChange={(e) => setAckUserId(e.target.value)}
                                    >
                                        <option value="">Anyone who can acknowledge</option>
                                        {ackCandidates.map((u) => (
                                            <option key={u.id} value={u.id}>
                                                {u.name} ({u.role})
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            {relayOnly && (
                                <div className="field">
                                    <label>Escalate To (Maintenance Supervisor / FSM)</label>
                                    <select
                                        className="neu-select"
                                        value={reviewerName}
                                        onChange={(e) => setReviewerName(e.target.value)}
                                    >
                                        <option value="">Select who this decision is for…</option>
                                        {assignableReviewers.map((u) => (
                                            <option key={u.id} value={u.name}>
                                                {u.name} ({u.role})
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            <div className="field">
                                <label>Notes (required)</label>
                                <input
                                    type="text"
                                    className="trigger-input"
                                    value={notes}
                                    onChange={(e) => setNotes(e.target.value)}
                                    placeholder="Describe the basis for this decision"
                                />
                            </div>
                            <div className="modal-actions" style={{ justifyContent: "flex-start", flexWrap: "nowrap", gap: 10 }}>
                                <button
                                    className="primary"
                                    disabled={!notes.trim()}
                                    title={!notes.trim() ? "Enter notes before recording a decision" : undefined}
                                    onClick={() => submitDecision(row, "Approved", relayOnly)}
                                >
                                    Approve
                                </button>
                                <button
                                    className="ghost"
                                    disabled={!notes.trim()}
                                    title={!notes.trim() ? "Enter notes before recording a decision" : undefined}
                                    onClick={() => submitDecision(row, "Reclassified", relayOnly)}
                                >
                                    Reclassify
                                </button>
                                <button
                                    className="danger"
                                    disabled={!notes.trim()}
                                    title={!notes.trim() ? "Enter notes before recording a decision" : undefined}
                                    onClick={() => submitDecision(row, "Rejected", relayOnly)}
                                >
                                    Reject
                                </button>
                                <button
                                    className="ghost"
                                    disabled={!notes.trim()}
                                    title={!notes.trim() ? "Enter notes before recording a decision" : undefined}
                                    onClick={() => submitDecision(row, "Carryforward", relayOnly)}
                                >
                                    Carryforward
                                </button>
                                <button className="ghost" onClick={() => setReviewingId(null)}>Cancel</button>
                            </div>
                        </div>
                    </div>
                );
            })()}

            {canAcknowledge && acknowledgmentRows.length > 0 && (
                <div style={{ marginTop: 32 }}>
                    <div className="header">
                        <h1>Needs Acknowledgment</h1>
                        <span className="sub">Moderate faults reviewed by a Maintenance Supervisor — Maintenance Manager/FSM to be informed, per the severity doc</span>
                    </div>
                    <div className="review-card-grid">
                        {acknowledgmentRows.map((row) => (
                            <div key={row.id} className="review-card pa-card">
                                <div className="pa-head">
                                    <div className="pa-title">{row.checklist_description ?? "Checklist item"}</div>
                                </div>
                                <div className="pa-meta">
                                    <span>{row.asset_code ?? "Unknown asset"}</span>
                                    <span>Report #{row.report_id}</span>
                                </div>
                                <dl className="pa-dl">
                                    <dt>Decision</dt>
                                    <dd>
                                        {row.decision}
                                        {row.new_severity ? ` → ${row.new_severity}` : ""} by {row.reviewer ?? "Unknown"} on {formatDate(row.updated_date)}
                                    </dd>
                                    {row.notes && (<><dt>Notes</dt><dd>{row.notes}</dd></>)}
                                </dl>
                                <div className="pa-foot">
                                    <div className="pa-btns">
                                        {onOpenFlow && (
                                            <button className="ghost pa-sm" onClick={() => onOpenFlow(row.report_id)}>Show flow</button>
                                        )}
                                        <button className="primary pa-sm" onClick={() => acknowledgeEntry(row)}>Acknowledge</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}

export default PendingApprovals;